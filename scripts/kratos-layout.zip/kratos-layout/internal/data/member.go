package data

import (
	"context"
	"time"

	"kratos-layout/internal/biz"
)

type Member struct {
	ID            int64   `xorm:"pk autoincr 'id'"`
	MemberName    string  `xorm:"'member_name'"`
	Password      string  `xorm:"'password'"`
	NickName      string  `xorm:"'nick_name'"`
	Balance       float64 `xorm:"'balance'"`
	Currency      string  `xorm:"'currency'"`
	State         int64   `xorm:"'state'"`
	LastLoginTime int64   `xorm:"'last_login_time'"`
	IP            string  `xorm:"'ip'"`
	MerchantID    int64   `xorm:"'merchant_id'"`
	Merchant      string  `xorm:"'merchant'"`
	Remark        string  `xorm:"'remark'"`
	IsDelete      int64   `xorm:"'is_delete'"`
	MemberType    int64   `xorm:"'member_type'"`
	TrueName      string  `xorm:"'true_name'"`
	TelPrefix     string  `xorm:"'tel_prefix'"`
	VipLevel      int64   `xorm:"'vip_level'"`
	Phone         string  `xorm:"'phone'"`
	ParentID      string  `xorm:"'parent_id'"`
	Email         string  `xorm:"'email'"`
	CreatedAt     int64   `xorm:"'created_at'"`
	UpdatedAt     int64   `xorm:"'updated_at'"`
	Version       int64   `xorm:"'version'"`
}

func (m *Member) TableName() string {
	return "member"
}

func (r *dataRepo) BatchUpsertMembers(ctx context.Context, members []biz.MemberInfo) error {
	if len(members) == 0 {
		return nil
	}

	session := r.data.db.NewSession().Context(ctx)
	defer session.Close()

	if err := session.Begin(); err != nil {
		return err
	}

	now := time.Now().Unix()

	for i := range members {
		m := members[i]
		// 检查是否存在
		var existing Member
		has, err := session.Table("member").Where("member_name = ?", m.MemberName).Get(&existing)
		if err != nil {
			_ = session.Rollback()
			return err
		}

		if has {
			// 如果存在：回填 ID（避免上层 UserID=0）
			members[i].ID = existing.ID
		} else {
			// 如果不存在，插入默认数据
			newMember := &Member{
				MemberName: m.MemberName,
				NickName:   m.MemberName,
				Balance:    m.Balance,
				Password:   "123456", // 默认密码
				State:      1,        // 启用
				IsDelete:   1,        // 正常
				MerchantID: 1,        // 默认商户
				Merchant:   "default",
				CreatedAt:  now,
				UpdatedAt:  now,
			}
			_, err := session.Insert(newMember)
			if err != nil {
				_ = session.Rollback()
				return err
			}
			// 回填自增 ID
			members[i].ID = newMember.ID
		}
	}

	return session.Commit()
}

func (r *dataRepo) GetMemberCount(ctx context.Context) (int64, error) {
	return r.data.db.Context(ctx).Table("member").Count()
}
