package data

import (
	"context"
	"fmt"

	"kratos-layout/internal/conf"

	"github.com/go-kratos/kratos/v2/log"
	_ "github.com/go-sql-driver/mysql"
	"github.com/google/wire"
	"github.com/redis/go-redis/v9"
	"xorm.io/xorm"
)

// ProviderSet is data providers.
var ProviderSet = wire.NewSet(NewData, NewMemberRepo, NewRedis, NewMysql)

// Data .
type Data struct {
	db  *xorm.Engine
	rdb redis.UniversalClient
}

// NewData .
func NewData(c *conf.Data, logger log.Logger, db *xorm.Engine, rdb redis.UniversalClient) (*Data, func(), error) {
	l := log.NewHelper(logger)
	cleanup := func() {
		l.Info("closing the data resources")
	}
	return &Data{db: db, rdb: rdb}, cleanup, nil
}

// NewRedis 创建并配置 Redis 客户端
func NewRedis(c *conf.Data, logger log.Logger) (redis.UniversalClient, func(), error) {
	l := log.NewHelper(logger)

	// 验证配置
	if len(c.Redis.Addr) == 0 {
		return nil, nil, fmt.Errorf("redis address is required")
	}

	rdb := redis.NewUniversalClient(&redis.UniversalOptions{
		Addrs:        c.Redis.Addr,
		Password:     c.Redis.Password,
		DB:           int(c.Redis.Db),
		ReadTimeout:  c.Redis.ReadTimeout.AsDuration(),
		WriteTimeout: c.Redis.WriteTimeout.AsDuration(),
	})

	// 测试 Redis 连接
	if err := rdb.Ping(context.Background()).Err(); err != nil {
		l.Errorf("failed pinging redis: %v", err)
		return nil, nil, err
	}

	cleanup := func() {
		l.Infof("closing redis connection")
		if err := rdb.Close(); err != nil {
			l.Error(err)
		}
	}

	l.Info("Redis connection established successfully")
	return rdb, cleanup, nil
}

// NewMysql 创建并配置 MySQL 数据库连接
func NewMysql(c *conf.Data, logger log.Logger) (*xorm.Engine, func(), error) {
	l := log.NewHelper(logger)

	// 构建 DSN 连接字符串
	dsn := c.Database.Source
	if dsn == "" {
		config := c.Database.Config
		if config == "" {
			config = "charset=utf8mb4&parseTime=True&loc=Local"
		}
		dsn = fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?%s",
			c.Database.Username,
			c.Database.Password,
			c.Database.Path,
			c.Database.Port,
			c.Database.DbName,
			config,
		)
	}

	// 创建数据库引擎
	db, err := xorm.NewEngine(c.Database.Driver, dsn)
	if err != nil {
		l.Errorf("failed opening connection to db: %v", err)
		return nil, nil, err
	}

	// 配置连接池
	maxIdleConns := int(c.Database.MaxIdleConns)
	if maxIdleConns <= 0 {
		maxIdleConns = 10 // 默认值
	}
	db.SetMaxIdleConns(maxIdleConns)

	maxOpenConns := int(c.Database.MaxOpenConns)
	if maxOpenConns <= 0 {
		maxOpenConns = 100 // 默认值
	}
	db.SetMaxOpenConns(maxOpenConns)

	//// 配置日志输出 - 使用适配器将 kratos logger 适配到 xorm logger
	//xormLogger := NewXormLogger(logger)
	//db.SetLogger(xormLogger)

	// 测试数据库连接
	if err := db.Ping(); err != nil {
		l.Errorf("failed pinging db: %v", err)
		_ = db.Close()
		return nil, nil, err
	}

	// 自动同步数据库表结构
	if err := db.Sync2(new(Member)); err != nil {
		l.Errorf("failed syncing database: %v", err)
		_ = db.Close()
		return nil, nil, err
	}

	cleanup := func() {
		l.Infof("closing mysql connection")
		if err := db.Close(); err != nil {
			l.Error(err)
		}
	}

	l.Info("MySQL database connection established successfully")
	return db, cleanup, nil
}
