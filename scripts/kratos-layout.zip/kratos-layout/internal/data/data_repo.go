package data

import (
	"kratos-layout/internal/biz"

	"github.com/go-kratos/kratos/v2/log"
)

type dataRepo struct {
	data *Data
	log  *log.Helper
}

func NewDataRepo(data *Data, logger log.Logger) biz.DataRepo {
	return &dataRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}
