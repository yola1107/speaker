package service

import (
	"context"
	"fmt"
	"strings"

	v1 "kratos-layout/api/stress/v1"
	"kratos-layout/internal/biz"
	"kratos-layout/internal/biz/task"

	kerrors "github.com/go-kratos/kratos/v2/errors"
	"github.com/go-kratos/kratos/v2/log"
	"google.golang.org/protobuf/types/known/emptypb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// StressService is a stress test service.
type StressService struct {
	v1.UnimplementedStressServiceServer

	uc  *biz.UseCase
	log *log.Helper
}

// NewStressService new a stress service.
func NewStressService(uc *biz.UseCase, logger log.Logger) *StressService {
	return &StressService{
		uc:  uc,
		log: log.NewHelper(logger),
	}
}

// SayHelloReq implements helloworld.GreeterServer.
func (s *StressService) SayHelloReq(ctx context.Context, in *v1.HelloRequest) (*v1.HelloReply, error) {
	//g, err := s.uc.CreateGreeter(ctx, &biz.Greeter{Hello: in.Name})
	//if err != nil {
	//	return nil, err
	//}
	return &v1.HelloReply{Message: "Hello " + in.Name}, nil
}

// ListGames 获取游戏列表
func (s *StressService) ListGames(ctx context.Context, req *v1.ListGamesRequest) (*v1.ListGamesResponse, error) {
	all := s.uc.ListGames()
	filtered := make([]*v1.Game, 0, len(all))
	for _, g := range all {
		filtered = append(filtered, &v1.Game{
			GameId:      g.GameID(),
			GameName:    g.Name(),
			Description: fmt.Sprintf("Stress test for game %s", g.Name()),
			IsActive:    true,
		})
	}
	s.log.WithContext(ctx).Infof("ListGames returned %d/%d games", len(filtered), len(all))
	return &v1.ListGamesResponse{
		Games: filtered,
		Total: int32(len(filtered)),
	}, nil
}

// CreateTask 创建压测任务
func (s *StressService) CreateTask(ctx context.Context, req *v1.CreateTaskRequest) (*v1.CreateTaskResponse, error) {
	s.log.WithContext(ctx).Infof("CreateTask request: %+v", req)

	if req == nil || req.Config == nil {
		return nil, fmt.Errorf("request cannot be nil")
	}

	config := req.Config

	// 业务逻辑校验：检查游戏是否存在
	if _, ok := s.uc.GetGame(config.GameId); !ok {
		return nil, kerrors.BadRequest("GAME_NOT_FOUND", fmt.Sprintf("game not found: %d", config.GameId))
	}

	// 创建并自动启动
	t, err := s.uc.CreateWithRequestID(ctx, req.RequestId, req.Name, req.Description, req.Config)
	if err != nil {
		return nil, fmt.Errorf("failed to create task: %v", err)
	}

	return &v1.CreateTaskResponse{Task: s.buildTaskProto(t)}, nil
}

// GetTask 获取任务详情
func (s *StressService) GetTask(ctx context.Context, req *v1.TaskRequest) (*v1.GetTaskResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}

	return &v1.GetTaskResponse{Task: s.buildTaskProto(t)}, nil
}

// GetTaskUserIds 获取任务分配到的用户ID列表
func (s *StressService) GetTaskUserIds(ctx context.Context, req *v1.TaskRequest) (*v1.GetTaskUserIdsResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}
	ids := t.GetUserIDs()
	return &v1.GetTaskUserIdsResponse{UserIds: ids, Total: int32(len(ids))}, nil
}

// ListTasks 获取任务列表
func (s *StressService) ListTasks(ctx context.Context, req *v1.ListTasksRequest) (*v1.ListTasksResponse, error) {
	all := s.uc.ListTasks()
	tasks := make([]*v1.Task, 0, len(all))

	filter := ""
	status := v1.TaskStatus_TASK_UNSPECIFIED
	if req != nil {
		filter = strings.ToLower(strings.TrimSpace(req.Filter))
		status = req.Status
	}

	for _, t := range all {
		// 1. 状态过滤
		if status != v1.TaskStatus_TASK_UNSPECIFIED && t.GetStatus() != status {
			continue
		}
		// 2. 关键字过滤
		if filter != "" && !strings.Contains(strings.ToLower(t.GetName()), filter) {
			continue
		}
		tasks = append(tasks, s.buildTaskProto(t))
	}

	return &v1.ListTasksResponse{
		Tasks: tasks,
		Total: int32(len(tasks)),
	}, nil
}

// GetTaskProgress 获取任务进度
func (s *StressService) GetTaskProgress(ctx context.Context, req *v1.TaskRequest) (*v1.GetTaskProgressResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}
	pbTask := s.buildTaskProto(t)
	return &v1.GetTaskProgressResponse{Progress: pbTask.Progress}, nil
}

// GetTaskStatistics 获取任务统计
func (s *StressService) GetTaskStatistics(ctx context.Context, req *v1.TaskRequest) (*v1.GetTaskStatisticsResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}
	pbTask := s.buildTaskProto(t)
	return &v1.GetTaskStatisticsResponse{Statistics: pbTask.Statistics}, nil
}

// GetSystemStatistics 获取系统统计
func (s *StressService) GetSystemStatistics(ctx context.Context, req *v1.GetSystemStatisticsRequest) (*v1.GetSystemStatisticsResponse, error) {
	_, allocated, total := s.uc.GetMemberStats()
	allTasks := s.uc.ListTasks()

	var running, pending int32
	for _, t := range allTasks {
		if t.GetStatus() == v1.TaskStatus_TASK_RUNNING {
			running++
		} else if t.GetStatus() == v1.TaskStatus_TASK_PENDING {
			pending++
		}
	}

	return &v1.GetSystemStatisticsResponse{
		Statistics: &v1.SystemStatistics{
			TotalGames:   int32(len(s.uc.ListGames())),
			ActiveGames:  int32(len(s.uc.ListGames())), // 目前所有加载的游戏都视为活跃
			TotalUsers:   int32(total),
			ActiveUsers:  int32(allocated),
			RunningTasks: running,
			PendingTasks: pending,
			CollectedAt:  timestamppb.Now(),
		},
	}, nil
}

// PauseTask 暂停任务
func (s *StressService) PauseTask(ctx context.Context, req *v1.TaskRequest) (*emptypb.Empty, error) {
	s.log.WithContext(ctx).Infof("PauseTask request: %+v", req)

	if req == nil {
		return nil, kerrors.BadRequest("BAD_REQUEST", "request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}
	t.SendSignal(int(v1.TaskStatus_TASK_PAUSED))

	return &emptypb.Empty{}, nil
}

// ResumeTask 恢复任务
func (s *StressService) ResumeTask(ctx context.Context, req *v1.TaskRequest) (*emptypb.Empty, error) {
	s.log.WithContext(ctx).Infof("ResumeTask request: %+v", req)

	if req == nil {
		return nil, kerrors.BadRequest("BAD_REQUEST", "request cannot be nil")
	}
	t, err := s.getTaskOrError(req.TaskId)
	if err != nil {
		return nil, err
	}
	t.SendSignal(int(v1.TaskStatus_TASK_RUNNING))

	return &emptypb.Empty{}, nil
}

// CancelTask 取消任务
func (s *StressService) CancelTask(ctx context.Context, req *v1.TaskRequest) (*emptypb.Empty, error) {
	s.log.WithContext(ctx).Infof("CancelTask request: %+v", req)

	if req == nil {
		return nil, kerrors.BadRequest("BAD_REQUEST", "request cannot be nil")
	}
	if err := s.uc.CancelTask(req.TaskId); err != nil {
		return nil, kerrors.InternalServer("CANCEL_FAILED", err.Error())
	}
	return &emptypb.Empty{}, nil
}

// DeleteTask 删除任务
func (s *StressService) DeleteTask(ctx context.Context, req *v1.TaskRequest) (*emptypb.Empty, error) {
	s.log.WithContext(ctx).Infof("DeleteTask request: %+v", req)

	if req == nil {
		return nil, kerrors.BadRequest("BAD_REQUEST", "request cannot be nil")
	}

	if err := s.uc.DeleteTask(req.TaskId); err != nil {
		return nil, kerrors.InternalServer("DELETE_FAILED", err.Error())
	}

	return &emptypb.Empty{}, nil
}

// ============================================================================
// 辅助函数
// ============================================================================

// 辅助函数：提取重复的任务获取和错误处理
func (s *StressService) getTaskOrError(taskID string) (*task.Task, error) {
	if taskID == "" {
		return nil, kerrors.BadRequest("BAD_REQUEST", "task_id is required")
	}
	t, ok := s.uc.GetTask(taskID)
	if !ok {
		return nil, kerrors.NotFound("TASK_NOT_FOUND", "task not found")
	}
	return t, nil
}

// 辅助函数：填充 Task proto 的进度和统计信息
func (s *StressService) fillTaskStats(t *task.Task, taskProto *v1.Task) {
	p, target, bo, bb, td := t.GetStats()
	activeMembers, completedMembers, failedMembers := t.GetMemberProgress()
	failedRequests := t.GetFailedRequests()

	// 填充进度
	taskProto.Progress = &v1.TaskProgress{
		TotalMembers:      t.GetConfig().MemberCount,
		CompletedMembers:  int32(completedMembers),
		ActiveMembers:     int32(activeMembers),
		FailedMembers:     int32(failedMembers),
		TotalRequests:     target,
		CompletedRequests: p,
		FailedRequests:    failedRequests,
	}
	if target > 0 {
		taskProto.Progress.CompletionRate = float64(p) / float64(target)
	}

	// 填充统计
	taskProto.Statistics = &v1.TaskStatistics{
		StartTime:         timestamppb.New(t.GetCreatedAt()),
		TotalDurationMs:   td.Milliseconds(),
		TotalBetOrders:    bo,
		TotalBetBonuses:   bb,
		Qps:               t.CalculateQPS(),
		AvgResponseTimeMs: t.CalculateAvgLatency(),
		SuccessRate:       t.CalculateSuccessRate(),
		ErrorRate:         1.0 - t.CalculateSuccessRate(),
		ErrorCounts:       t.GetErrorStats(),
	}
	if !t.GetFinishedAt().IsZero() {
		taskProto.Statistics.EndTime = timestamppb.New(t.GetFinishedAt())
	}
}

// 辅助函数：构建 Task proto 对象
func (s *StressService) buildTaskProto(t *task.Task) *v1.Task {
	taskProto := &v1.Task{
		TaskId:      t.GetID(),
		Name:        t.GetName(),
		Description: t.GetDescription(),
		Status:      t.GetStatus(),
		Config:      t.GetConfig(),
		UserCount:   int32(t.UserIDCount()),
		CreatedAt:   timestamppb.New(t.GetCreatedAt()),
		UpdatedAt:   timestamppb.New(t.GetCreatedAt()),
	}
	s.fillTaskStats(t, taskProto)
	return taskProto
}
