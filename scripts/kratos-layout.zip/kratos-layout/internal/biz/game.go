package biz

import (
	"kratos-layout/internal/biz/game/base"
	"kratos-layout/internal/biz/game/g18890"
)

// 游戏注册表：在此添加新游戏
var gameInstances = []base.IGame{
	g18890.New(18890, "战火西岐"),
}
