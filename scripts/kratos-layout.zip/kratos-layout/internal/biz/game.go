package biz

import (
	"kratos-layout/internal/biz/game/base"
	"kratos-layout/internal/biz/game/g18890"
)

// 注册所有游戏实例：在此添加新游戏，无需额外的结构体定义
var instances = []base.IGame{
	g18890.New(18890, "战火西岐"),
	// g18891.New(18891, "其他游戏"),
}
