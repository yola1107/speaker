package task

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	v1 "kratos-layout/api/stress/v1"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/panjf2000/ants/v2"
)

// Task 压测任务结构体
type Task struct {
	id          string
	description string
	status      v1.TaskStatus
	config      *v1.TaskConfig
	createdAt   time.Time
	finishedAt  time.Time
	userIDs     []int64

	mu     sync.RWMutex
	pool   *ants.Pool
	ctx    context.Context
	cancel context.CancelFunc

	// 统计信息（原子操作，对齐 go-rtp-tool 的全局统计）
	process       int64
	target        int64
	betOrderCount int64
	betBonusCount int64
	totalDuration int64 // 纳秒

	// TaskProgress 补齐：成员与失败请求统计
	activeMembers    int64
	completedMembers int64
	failedMembers    int64
	failedRequests   int64

	errorMu     sync.Mutex
	errorCounts map[string]int64
}

// NewTask 创建新任务
func NewTask(id, description string, config *v1.TaskConfig) (*Task, error) {
	capacity := 1000
	if config != nil && config.MemberCount > 0 {
		capacity = int(config.MemberCount)
	}

	pool, err := ants.NewPool(capacity)
	if err != nil {
		return nil, fmt.Errorf("failed to create ants pool: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())

	var targetCount int64
	if config != nil {
		targetCount = int64(config.MemberCount) * int64(config.TimesPerMember)
	}

	return &Task{
		id:          id,
		description: description,
		status:      v1.TaskStatus_TASK_PENDING,
		config:      config,
		createdAt:   time.Now(),
		pool:        pool,
		ctx:         ctx,
		cancel:      cancel,
		target:      targetCount,
		errorCounts: make(map[string]int64),
	}, nil
}

// MetaSnapshot 一次性获取所有元数据字段，减少锁竞争
type MetaSnapshot struct {
	ID          string
	Description string
	Status      v1.TaskStatus
	Config      *v1.TaskConfig
	UserIDCount int
}

func (t *Task) MetaSnapshot() MetaSnapshot {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return MetaSnapshot{
		ID:          t.id,
		Description: t.description,
		Status:      t.status,
		Config:      t.config,
		UserIDCount: len(t.userIDs),
	}
}

// GetID 获取任务ID
func (t *Task) GetID() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.id
}

// GetDescription 获取任务描述
func (t *Task) GetDescription() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.description
}

// GetConfig 获取任务配置
func (t *Task) GetConfig() *v1.TaskConfig {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.config
}

// GetCreatedAt 获取创建时间
func (t *Task) GetCreatedAt() time.Time {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.createdAt
}

// GetFinishedAt 获取结束时间
func (t *Task) GetFinishedAt() time.Time {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.finishedAt
}

// SetUserIDs 设置该任务已分配的压测用户ID（会持久保留到任务结束后用于查询）
func (t *Task) SetUserIDs(ids []int64) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(ids) == 0 {
		t.userIDs = nil
		return
	}
	t.userIDs = append([]int64(nil), ids...)
}

// GetUserIDs 获取该任务分配到的压测用户ID列表
func (t *Task) GetUserIDs() []int64 {
	t.mu.RLock()
	defer t.mu.RUnlock()
	if len(t.userIDs) == 0 {
		return nil
	}
	return append([]int64(nil), t.userIDs...)
}

// UserIDCount 获取该任务分配到的用户数量（避免拷贝 userIDs）
func (t *Task) UserIDCount() int {
	return t.MetaSnapshot().UserIDCount
}

// GetStatus 获取任务状态
func (t *Task) GetStatus() v1.TaskStatus {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.status
}

// Context 获取任务关联的 Context
func (t *Task) Context() context.Context {
	return t.ctx
}

// isTerminalStatus 判断是否为终态（完成/失败/取消）
func isTerminalStatus(status v1.TaskStatus) bool {
	return status == v1.TaskStatus_TASK_COMPLETED ||
		status == v1.TaskStatus_TASK_FAILED ||
		status == v1.TaskStatus_TASK_CANCELLED
}

// SetStatus 设置任务状态并同步控制通道
func (t *Task) SetStatus(status v1.TaskStatus) {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.status == status {
		return
	}
	if isTerminalStatus(status) && t.finishedAt.IsZero() {
		t.finishedAt = time.Now()
	}
	t.status = status
}

// IsFinished 检查任务是否已进入终态
func (t *Task) IsFinished() bool {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return isTerminalStatus(t.status)
}

// Cancel 取消任务执行
func (t *Task) Cancel() error {
	t.mu.Lock()
	defer t.mu.Unlock()

	if isTerminalStatus(t.status) {
		return fmt.Errorf("task already finished")
	}

	t.status = v1.TaskStatus_TASK_CANCELLED
	if t.cancel != nil {
		t.cancel()
	}

	log.Infof("[task %s] cancelled", t.id)
	return nil
}

// Start 启动任务进入运行状态
func (t *Task) Start() error {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.status != v1.TaskStatus_TASK_PENDING {
		return fmt.Errorf("task status %v cannot be started", t.status)
	}

	t.status = v1.TaskStatus_TASK_RUNNING
	log.Infof("[task %s] started at %s", t.id, t.createdAt.Format("15:04:05"))
	return nil
}

// Stop 停止任务并彻底释放协程池资源
func (t *Task) Stop() {
	t.mu.Lock()
	if t.cancel != nil {
		t.cancel()
	}

	p := t.pool
	t.pool = nil
	t.mu.Unlock()

	if p != nil {
		p.Release()
	}

	log.Infof("[task %s] stopped", t.id)
}

// Submit 提交会话执行逻辑到内置协程池
func (t *Task) Submit(task func()) error {
	t.mu.RLock()
	defer t.mu.RUnlock()

	if t.pool == nil {
		return fmt.Errorf("task pool already released")
	}
	return t.pool.Submit(task)
}

// MarkMemberStart 标记一个成员开始执行
func (t *Task) MarkMemberStart() {
	atomic.AddInt64(&t.activeMembers, 1)
}

// MarkMemberDone 标记一个成员执行结束
func (t *Task) MarkMemberDone(failed bool) {
	atomic.AddInt64(&t.activeMembers, -1)
	if failed {
		atomic.AddInt64(&t.failedMembers, 1)
	} else {
		atomic.AddInt64(&t.completedMembers, 1)
	}
}

// =================统计信息相关方法 (原子操作)=================

// addStep 统一累加统计（betOrder +1 或 betBonus +1）
func (t *Task) addStep(betOrder, betBonus int64, duration time.Duration, spinOver bool) {
	if betOrder > 0 {
		atomic.AddInt64(&t.betOrderCount, betOrder)
	}
	if betBonus > 0 {
		atomic.AddInt64(&t.betBonusCount, betBonus)
	}
	atomic.AddInt64(&t.totalDuration, duration.Nanoseconds())
	if spinOver {
		atomic.AddInt64(&t.process, 1)
	}
}

// AddBetOrder 累加下注统计
func (t *Task) AddBetOrder(duration time.Duration, spinOver bool) {
	t.addStep(1, 0, duration, spinOver)
}

// AddBetBonus 累加奖励下注统计
func (t *Task) AddBetBonus(duration time.Duration, spinOver bool) {
	t.addStep(0, 1, duration, spinOver)
}

// AddError 记录错误统计
func (t *Task) AddError(errMsg string) {
	t.errorMu.Lock()
	defer t.errorMu.Unlock()
	t.errorCounts[errMsg]++
	atomic.AddInt64(&t.failedRequests, 1)
}

// StatsSnapshot 一次取齐的统计快照，供 proto 填充用，避免重复 Load 与锁。
type StatsSnapshot struct {
	Process, Target, BetOrders, BetBonuses         int64
	TotalDuration                                  time.Duration
	ActiveMembers, CompletedMembers, FailedMembers int64
	FailedRequests                                 int64
	CreatedAt, FinishedAt                          time.Time
	Config                                         *v1.TaskConfig
	ErrorCounts                                    map[string]int64
}

func (t *Task) StatsSnapshot() StatsSnapshot {
	t.mu.RLock()
	createdAt, finishedAt, cfg := t.createdAt, t.finishedAt, t.config
	t.mu.RUnlock()
	t.errorMu.Lock()
	ec := make(map[string]int64, len(t.errorCounts))
	for k, v := range t.errorCounts {
		ec[k] = v
	}
	t.errorMu.Unlock()
	return StatsSnapshot{
		Process:          atomic.LoadInt64(&t.process),
		Target:           atomic.LoadInt64(&t.target),
		BetOrders:        atomic.LoadInt64(&t.betOrderCount),
		BetBonuses:       atomic.LoadInt64(&t.betBonusCount),
		TotalDuration:    time.Duration(atomic.LoadInt64(&t.totalDuration)),
		ActiveMembers:    atomic.LoadInt64(&t.activeMembers),
		CompletedMembers: atomic.LoadInt64(&t.completedMembers),
		FailedMembers:    atomic.LoadInt64(&t.failedMembers),
		FailedRequests:   atomic.LoadInt64(&t.failedRequests),
		CreatedAt:        createdAt,
		FinishedAt:       finishedAt,
		Config:           cfg,
		ErrorCounts:      ec,
	}
}

func (s *StatsSnapshot) QPS() float64 {
	end := time.Now()
	if !s.FinishedAt.IsZero() {
		end = s.FinishedAt
	}
	d := end.Sub(s.CreatedAt).Seconds()
	if d <= 0 {
		return 0
	}
	return float64(s.Process) / d
}

func (s *StatsSnapshot) AvgLatencyMs() float64 {
	total := s.BetOrders + s.BetBonuses
	if total <= 0 {
		return 0
	}
	return float64(s.TotalDuration.Milliseconds()) / float64(total)
}

func (s *StatsSnapshot) SuccessRate() float64 {
	if s.Process <= 0 {
		return 0
	}
	return float64(s.Process-s.FailedRequests) / float64(s.Process)
}

// =================进度监控与格式化 =================

// progressSnapshot 监控用的进度快照，一次 Load 全部原子值
type progressSnapshot struct {
	id            string
	process       int64
	target        int64
	step          int64
	totalDuration time.Duration
}

func (t *Task) loadProgressSnapshot() progressSnapshot {
	bo := atomic.LoadInt64(&t.betOrderCount)
	bb := atomic.LoadInt64(&t.betBonusCount)
	return progressSnapshot{
		id:            t.id, // 不可变，无需锁
		process:       atomic.LoadInt64(&t.process),
		target:        atomic.LoadInt64(&t.target),
		step:          bo + bb,
		totalDuration: time.Duration(atomic.LoadInt64(&t.totalDuration)),
	}
}

// Monitor 启动进度监控协程，每秒打印一次进度
func (t *Task) Monitor(ctx context.Context) {
	start := time.Now()
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			t.printFinalStats(start)
			return
		case <-t.ctx.Done():
			t.printFinalStats(start)
			return
		case <-ticker.C:
			t.printProgress(start)
		}
	}
}

func (t *Task) printProgress(start time.Time) {
	snap := t.loadProgressSnapshot()
	elapsed := time.Since(start)

	pct := float64(0)
	if snap.target > 0 {
		pct = float64(snap.process) / float64(snap.target) * 100
	}
	remaining := time.Duration(0)
	if pct > 0 {
		remaining = time.Duration(int64(float64(elapsed)/pct*100)) - elapsed
	}

	log.Infof("%s [%s]: 进度:%d/%d(%.2f%%), 用时:%s, 剩余:%s, QPS:%.2f, step:%.2f, 延迟:%s    ",
		time.Now().Format("15:04:05"),
		snap.id,
		snap.process, snap.target, pct,
		ShortDuration(elapsed),
		ShortDuration(remaining),
		float64(snap.process)/elapsed.Seconds(),
		float64(snap.step)/elapsed.Seconds(),
		avgDuration(snap.totalDuration, snap.step),
	)
}

func (t *Task) printFinalStats(start time.Time) {
	snap := t.loadProgressSnapshot()
	elapsed := time.Since(start)

	log.Infof("[%s] 任务结束: 进度:%d/%d, 总步数:%d, 耗时:%v, QPS:%.2f, 平均延迟:%s\n",
		snap.id, snap.process, snap.target, snap.step, elapsed,
		float64(snap.process)/elapsed.Seconds(),
		avgDuration(snap.totalDuration, snap.step),
	)
}

// avgDuration 安全地计算平均延时
func avgDuration(duration time.Duration, step int64) string {
	if step == 0 {
		return "0"
	}
	return ShortDuration(time.Duration(int64(duration) / step))
}

// ShortDuration 格式化时间跨度（对齐 go-rtp-tool）
func ShortDuration(d time.Duration) string {
	if d == 0 {
		return "0"
	}
	sec := d.Seconds()
	for _, u := range []struct {
		div float64
		sym string
	}{
		{60 * 60 * 24, "d"},
		{60 * 60, "h"},
		{60, "m"},
		{1, "s"},
		{1e-3, "ms"},
		{1e-6, "µs"},
		{1e-9, "ns"},
	} {
		if sec >= u.div {
			val := sec / u.div
			if val >= 100 {
				return fmt.Sprintf("%.0f%s", val, u.sym)
			} else if val >= 10 {
				return fmt.Sprintf("%.1f%s", val, u.sym)
			}
			return fmt.Sprintf("%.2f%s", val, u.sym)
		}
	}
	return "0"
}
