package task

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	v1 "kratos-layout/api/stress/v1"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/panjf2000/ants/v2"
)

// Task 压测任务结构体
type Task struct {
	id          string
	name        string
	description string
	status      v1.TaskStatus
	config      *v1.TaskConfig
	createdAt   time.Time
	finishedAt  time.Time
	userIDs     []int64

	mu       sync.RWMutex
	pool     *ants.Pool
	ctx      context.Context
	cancel   context.CancelFunc
	resumeCh chan struct{}

	// 统计信息（原子操作，对齐 go-rtp-tool 的全局统计）
	process       int64
	target        int64
	betOrderCount int64
	betBonusCount int64
	totalDuration int64 // 纳秒

	// TaskProgress 补齐：成员与失败请求统计
	activeMembers    int64
	completedMembers int64
	failedMembers    int64
	failedRequests   int64

	errorMu     sync.Mutex
	errorCounts map[string]int64
}

// NewTask 创建新任务
func NewTask(id, name, description string, config *v1.TaskConfig) (*Task, error) {
	capacity := 1000
	if config != nil && config.MemberCount > 0 {
		capacity = int(config.MemberCount)
	}

	pool, err := ants.NewPool(capacity)
	if err != nil {
		return nil, fmt.Errorf("failed to create ants pool: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())

	// 初始化为已关闭的通道（非阻塞状态）
	resumeCh := make(chan struct{})
	close(resumeCh)

	var targetCount int64
	if config != nil {
		targetCount = int64(config.MemberCount) * int64(config.TimesPerMember)
	}

	return &Task{
		id:          id,
		name:        name,
		description: description,
		status:      v1.TaskStatus_TASK_PENDING,
		config:      config,
		createdAt:   time.Now(),
		pool:        pool,
		ctx:         ctx,
		cancel:      cancel,
		resumeCh:    resumeCh,
		target:      targetCount,
		errorCounts: make(map[string]int64),
	}, nil
}

// GetID 获取任务ID
func (t *Task) GetID() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.id
}

// GetName 获取任务名称
func (t *Task) GetName() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.name
}

// GetDescription 获取任务描述
func (t *Task) GetDescription() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.description
}

// GetConfig 获取任务配置
func (t *Task) GetConfig() *v1.TaskConfig {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.config
}

// GetCreatedAt 获取创建时间
func (t *Task) GetCreatedAt() time.Time {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.createdAt
}

// GetFinishedAt 获取结束时间
func (t *Task) GetFinishedAt() time.Time {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.finishedAt
}

// SetUserIDs 设置该任务已分配的压测用户ID（会持久保留到任务结束后用于查询）
func (t *Task) SetUserIDs(ids []int64) {
	t.mu.Lock()
	defer t.mu.Unlock()

	if len(ids) == 0 {
		t.userIDs = nil
		return
	}
	cp := make([]int64, len(ids))
	copy(cp, ids)
	t.userIDs = cp
}

// GetUserIDs 获取该任务分配到的压测用户ID列表
func (t *Task) GetUserIDs() []int64 {
	t.mu.RLock()
	defer t.mu.RUnlock()
	if len(t.userIDs) == 0 {
		return nil
	}
	cp := make([]int64, len(t.userIDs))
	copy(cp, t.userIDs)
	return cp
}

// UserIDCount 获取该任务分配到的用户数量（避免拷贝 userIDs）
func (t *Task) UserIDCount() int {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return len(t.userIDs)
}

// GetStatus 获取任务状态
func (t *Task) GetStatus() v1.TaskStatus {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.status
}

// Context 获取任务关联的 Context
func (t *Task) Context() context.Context {
	return t.ctx
}

// SetStatus 设置任务状态并同步控制通道
func (t *Task) SetStatus(status v1.TaskStatus) {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.status == status {
		return
	}

	// 记录结束时间
	if (status == v1.TaskStatus_TASK_COMPLETED || status == v1.TaskStatus_TASK_FAILED || status == v1.TaskStatus_TASK_CANCELLED) && t.finishedAt.IsZero() {
		t.finishedAt = time.Now()
	}

	// 处理暂停/恢复的阻塞通道逻辑
	if status == v1.TaskStatus_TASK_PAUSED {
		if t.status != v1.TaskStatus_TASK_PAUSED {
			t.resumeCh = make(chan struct{})
		}
	} else if t.status == v1.TaskStatus_TASK_PAUSED {
		if t.resumeCh != nil {
			close(t.resumeCh)
		}
	}

	t.status = status
}

// IsFinished 检查任务是否已进入终态
func (t *Task) IsFinished() bool {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.status == v1.TaskStatus_TASK_COMPLETED ||
		t.status == v1.TaskStatus_TASK_FAILED ||
		t.status == v1.TaskStatus_TASK_CANCELLED
}

// Cancel 取消任务执行
func (t *Task) Cancel() error {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.status == v1.TaskStatus_TASK_COMPLETED ||
		t.status == v1.TaskStatus_TASK_FAILED ||
		t.status == v1.TaskStatus_TASK_CANCELLED {
		return fmt.Errorf("task already finished")
	}

	t.status = v1.TaskStatus_TASK_CANCELLED
	if t.cancel != nil {
		t.cancel()
	}

	log.Infof("[task %s] cancelled", t.id)
	return nil
}

// Start 启动任务进入运行状态
func (t *Task) Start() error {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.status != v1.TaskStatus_TASK_PENDING {
		return fmt.Errorf("task status %v cannot be started", t.status)
	}

	t.status = v1.TaskStatus_TASK_RUNNING
	log.Infof("[task %s] started at %s", t.id, t.createdAt.Format("15:04:05"))
	return nil
}

// SendSignal 发送控制信号（简化为直接修改状态）
func (t *Task) SendSignal(sig int) {
	status := v1.TaskStatus(sig)
	switch status {
	case v1.TaskStatus_TASK_RUNNING, v1.TaskStatus_TASK_PAUSED:
		t.SetStatus(status)
	case v1.TaskStatus_TASK_CANCELLED:
		_ = t.Cancel()
	}
}

// Stop 停止任务并彻底释放协程池资源
func (t *Task) Stop() {
	t.mu.Lock()
	if t.cancel != nil {
		t.cancel()
	}

	p := t.pool
	t.pool = nil
	t.mu.Unlock()

	if p != nil {
		p.Release()
	}

	log.Infof("[task %s] stopped", t.id)
}

// Submit 提交会话执行逻辑到内置协程池
func (t *Task) Submit(task func()) error {
	t.mu.RLock()
	defer t.mu.RUnlock()

	if t.pool == nil {
		return fmt.Errorf("task pool already released")
	}
	return t.pool.Submit(task)
}

// WaitIfPaused 提供给 Session 使用的阻塞点，实现暂停功能
func (t *Task) WaitIfPaused(ctx context.Context) error {
	t.mu.RLock()
	ch := t.resumeCh
	t.mu.RUnlock()

	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.ctx.Done():
		return t.ctx.Err()
	case <-ch: // 如果通道关闭（Running），立即返回；否则阻塞等待关闭
		return nil
	}
}

// MarkMemberStart 标记一个成员开始执行
func (t *Task) MarkMemberStart() {
	atomic.AddInt64(&t.activeMembers, 1)
}

// MarkMemberDone 标记一个成员执行结束
func (t *Task) MarkMemberDone(failed bool) {
	atomic.AddInt64(&t.activeMembers, -1)
	if failed {
		atomic.AddInt64(&t.failedMembers, 1)
	} else {
		atomic.AddInt64(&t.completedMembers, 1)
	}
}

// GetMemberProgress 获取成员维度进度
func (t *Task) GetMemberProgress() (active, completed, failed int64) {
	return atomic.LoadInt64(&t.activeMembers),
		atomic.LoadInt64(&t.completedMembers),
		atomic.LoadInt64(&t.failedMembers)
}

// GetFailedRequests 获取失败请求数（以错误次数近似）
func (t *Task) GetFailedRequests() int64 {
	return atomic.LoadInt64(&t.failedRequests)
}

// =================统计信息相关方法 (原子操作)=================

// AddBetOrder 累加下注统计
func (t *Task) AddBetOrder(duration time.Duration, spinOver bool) {
	atomic.AddInt64(&t.betOrderCount, 1)
	atomic.AddInt64(&t.totalDuration, duration.Nanoseconds())
	if spinOver {
		atomic.AddInt64(&t.process, 1)
	}
}

// AddBetBonus 累加奖励下注统计
func (t *Task) AddBetBonus(duration time.Duration, spinOver bool) {
	atomic.AddInt64(&t.betBonusCount, 1)
	atomic.AddInt64(&t.totalDuration, duration.Nanoseconds())
	if spinOver {
		atomic.AddInt64(&t.process, 1)
	}
}

// GetStats 获取汇总统计
func (t *Task) GetStats() (process, target, betOrders, betBonuses int64, totalDuration time.Duration) {
	return atomic.LoadInt64(&t.process),
		atomic.LoadInt64(&t.target),
		atomic.LoadInt64(&t.betOrderCount),
		atomic.LoadInt64(&t.betBonusCount),
		time.Duration(atomic.LoadInt64(&t.totalDuration))
}

// CalculateQPS 计算当前 QPS
func (t *Task) CalculateQPS() float64 {
	p := atomic.LoadInt64(&t.process)
	start := t.GetCreatedAt()
	end := time.Now()
	if !t.finishedAt.IsZero() {
		end = t.finishedAt
	}
	duration := end.Sub(start).Seconds()
	if duration > 0 {
		return float64(p) / duration
	}
	return 0
}

// CalculateAvgLatency 计算平均延迟 (ms)
func (t *Task) CalculateAvgLatency() float64 {
	td := atomic.LoadInt64(&t.totalDuration)
	bo := atomic.LoadInt64(&t.betOrderCount)
	bb := atomic.LoadInt64(&t.betBonusCount)
	total := bo + bb
	if total > 0 {
		return float64(time.Duration(td).Milliseconds()) / float64(total)
	}
	return 0
}

// CalculateSuccessRate 计算成功率 (0-1)
func (t *Task) CalculateSuccessRate() float64 {
	p := atomic.LoadInt64(&t.process)
	failed := atomic.LoadInt64(&t.failedRequests)
	if p > 0 {
		return float64(p-failed) / float64(p)
	}
	return 0
}

// AddError 记录错误统计
func (t *Task) AddError(errMsg string) {
	t.errorMu.Lock()
	defer t.errorMu.Unlock()
	t.errorCounts[errMsg]++
	atomic.AddInt64(&t.failedRequests, 1)
}

// GetErrorStats 获取错误统计
func (t *Task) GetErrorStats() map[string]int64 {
	t.errorMu.Lock()
	defer t.errorMu.Unlock()
	res := make(map[string]int64, len(t.errorCounts))
	for k, v := range t.errorCounts {
		res[k] = v
	}
	return res
}

// =================进度监控与格式化 =================

// Monitor 启动进度监控协程，每秒打印一次进度
func (t *Task) Monitor(ctx context.Context) {
	start := time.Now()
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			t.printFinalStats(start)
			return
		case <-t.ctx.Done():
			t.printFinalStats(start)
			return
		case <-ticker.C:
			t.printProgress(start)
		}
	}
}

func (t *Task) printProgress(start time.Time) {
	p := atomic.LoadInt64(&t.process)
	tr := atomic.LoadInt64(&t.target)
	bo := atomic.LoadInt64(&t.betOrderCount)
	bb := atomic.LoadInt64(&t.betBonusCount)
	step := bo + bb
	td := atomic.LoadInt64(&t.totalDuration)

	timeDura := time.Since(start)
	procePercentage := float64(0)
	if tr > 0 {
		procePercentage = float64(p) / float64(tr) * 100
	}

	restDura := time.Duration(0)
	if procePercentage > 0 {
		restDura = time.Duration(int64(float64(timeDura)/procePercentage*100)) - timeDura
	}

	fmt.Printf("\r%s [%s]: 进度:%d/%d(%.2f%%), 用时:%s, 剩余:%s, QPS:%.2f, step:%.2f, 延迟:%s    ",
		time.Now().Format("15:04:05"),
		t.id,
		p, tr, procePercentage,
		ShortDuration(timeDura),
		ShortDuration(restDura),
		float64(p)/timeDura.Seconds(),
		float64(step)/timeDura.Seconds(),
		avgDuration(time.Duration(td), step),
	)
}

func (t *Task) printFinalStats(start time.Time) {
	end := time.Now()
	p := atomic.LoadInt64(&t.process)
	tr := atomic.LoadInt64(&t.target)
	bo := atomic.LoadInt64(&t.betOrderCount)
	bb := atomic.LoadInt64(&t.betBonusCount)
	step := bo + bb
	td := atomic.LoadInt64(&t.totalDuration)

	fmt.Printf("\n\n[%s] 任务结束: 进度:%d/%d, 总步数:%d, 耗时:%v, QPS:%.2f, 平均延迟:%s\n",
		t.id, p, tr, step, end.Sub(start),
		float64(p)/end.Sub(start).Seconds(),
		avgDuration(time.Duration(td), step),
	)
}

// avgDuration 安全地计算平均延时
func avgDuration(duration time.Duration, step int64) string {
	if step == 0 {
		return "0"
	}
	return ShortDuration(time.Duration(int64(duration) / step))
}

// ShortDuration 格式化时间跨度（对齐 go-rtp-tool）
func ShortDuration(d time.Duration) string {
	if d == 0 {
		return "0"
	}
	sec := d.Seconds()
	for _, u := range []struct {
		div float64
		sym string
	}{
		{60 * 60 * 24, "d"},
		{60 * 60, "h"},
		{60, "m"},
		{1, "s"},
		{1e-3, "ms"},
		{1e-6, "µs"},
		{1e-9, "ns"},
	} {
		if sec >= u.div {
			val := sec / u.div
			if val >= 100 {
				return fmt.Sprintf("%.0f%s", val, u.sym)
			} else if val >= 10 {
				return fmt.Sprintf("%.1f%s", val, u.sym)
			}
			return fmt.Sprintf("%.2f%s", val, u.sym)
		}
	}
	return "0"
}
