package biz

import (
	"context"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	v1 "kratos-layout/api/stress/v1"
	"kratos-layout/internal/biz/task"
	"kratos-layout/internal/biz/user"
)

var openAutoLoads = true

// schedule 核心调度：谁放人，谁就喊“下一位”
func (uc *UseCase) schedule() {
	uc.mu.Lock()
	defer uc.mu.Unlock()

	for len(uc.pendingQueue) > 0 {
		taskID := uc.pendingQueue[0]
		t, ok := uc.allTasks[taskID]
		if !ok || t.GetStatus() != v1.TaskStatus_TASK_PENDING {
			uc.pendingQueue = uc.pendingQueue[1:]
			continue
		}

		config := t.GetConfig()
		count := int(config.MemberCount)

		// 资源检查
		if len(uc.idleMembers) < count {
			break // 资源不足，继续排队
		}

		// 分配资源
		uc.pendingQueue = uc.pendingQueue[1:]
		allocated := append([]MemberInfo{}, uc.idleMembers[:count]...)
		uc.idleMembers = uc.idleMembers[count:]
		uc.allocatedMembers[taskID] = allocated

		// 持久记录该任务分配到的玩家ID（用于 CreateTask/GetTask 返回）
		ids := make([]int64, 0, len(allocated))
		for _, m := range allocated {
			ids = append(ids, m.ID)
		}
		t.SetUserIDs(ids)

		// 启动任务
		if err := t.Start(); err == nil {
			go uc.runTaskSessions(t, allocated)
		} else {
			// 启动失败回滚
			t.SetUserIDs(nil)
			uc.idleMembers = append(uc.idleMembers, allocated...)
			delete(uc.allocatedMembers, taskID)
		}
	}
}

// runTaskSessions 运行压测 Session，并负责在结束时“收摊”
func (uc *UseCase) runTaskSessions(t *task.Task, members []MemberInfo) {
	taskID := t.GetID()
	config := t.GetConfig()
	g, _ := uc.GetGame(config.GameId)
	sp := func(merchant string) (string, bool) { return "", false }

	// 1. 启动进度监控
	monitorCtx, monitorCancel := context.WithCancel(t.Context())
	go t.Monitor(monitorCtx)

	// 2. 核心执行循环
	var wg sync.WaitGroup
	wg.Add(len(members))

	for _, m := range members {
		member := m
		sess := user.NewSession(member.ID, member.MemberName, config.GameId, taskID, t, uc.protobufGames)
		t.MarkMemberStart()
		if err := t.Submit(func() {
			defer wg.Done()
			// 注意：defer 的参数会在注册时求值，必须用闭包延迟求值，才能拿到 Execute 后的状态
			defer func() { t.MarkMemberDone(sess.IsFailed()) }()
			// 执行压测逻辑
			_ = sess.Execute(t.Context(), config, g, sp, uc.logger)
		}); err != nil {
			// 提交失败视为该成员失败结束，避免 wg 永久等待
			wg.Done()
			t.MarkMemberDone(true)
		}
	}

	// 等待所有 Session 协程退出
	wg.Wait()

	// 3. 开始清理资源
	monitorCancel() // 停止监控协程并触发最终统计打印

	uc.mu.Lock()
	// A. 将玩家资源放回空闲池，并从已分配映射中移除
	if allocated, ok := uc.allocatedMembers[taskID]; ok {
		uc.idleMembers = append(uc.idleMembers, allocated...)
		delete(uc.allocatedMembers, taskID)
	}

	// B. 如果任务是正常运行结束的，更新其状态为已完成
	if t.GetStatus() == v1.TaskStatus_TASK_RUNNING {
		t.SetStatus(v1.TaskStatus_TASK_COMPLETED)
	}
	uc.mu.Unlock()

	// C. 彻底停止任务，释放内部 ants.Pool 协程池和 Context
	t.Stop()

	// 4. 资源已完全释放，触发下一轮排队任务的调度
	uc.schedule()
}

// Create 创建并尝试运行
func (uc *UseCase) Create(ctx context.Context, name, description string, config *v1.TaskConfig) (*task.Task, error) {
	return uc.CreateWithRequestID(ctx, "", name, description, config)
}

// CreateWithRequestID 创建并尝试运行（支持 request_id 幂等去重）
func (uc *UseCase) CreateWithRequestID(ctx context.Context, requestID, name, description string, config *v1.TaskConfig) (*task.Task, error) {
	requestID = strings.TrimSpace(requestID)

	uc.mu.Lock()
	if requestID != "" {
		// 简单的容量控制：避免 requestToTask 无限增长
		const maxIdempotencyEntries = 10000
		if len(uc.requestToTask) > maxIdempotencyEntries {
			uc.requestToTask = make(map[string]string)
		}

		if existingTaskID, ok := uc.requestToTask[requestID]; ok {
			if existingTask, ok2 := uc.allTasks[existingTaskID]; ok2 {
				uc.mu.Unlock()
				return existingTask, nil
			}
			delete(uc.requestToTask, requestID)
		}
	}
	uc.counter[config.GameId]++
	taskID := fmt.Sprintf("%d-%d", config.GameId, uc.counter[config.GameId])
	uc.mu.Unlock()

	t, err := task.NewTask(taskID, name, description, config)
	if err != nil {
		return nil, err
	}

	uc.mu.Lock()
	uc.allTasks[taskID] = t
	uc.pendingQueue = append(uc.pendingQueue, taskID)
	if requestID != "" {
		uc.requestToTask[requestID] = taskID
	}
	uc.mu.Unlock()

	uc.schedule()
	return t, nil
}

func (uc *UseCase) DeleteTask(id string) error {
	uc.mu.Lock()
	t, ok := uc.allTasks[id]
	if ok {
		delete(uc.allTasks, id)
	}
	// 释放资源
	if members, exists := uc.allocatedMembers[id]; exists {
		uc.idleMembers = append(uc.idleMembers, members...)
		delete(uc.allocatedMembers, id)
	}
	uc.mu.Unlock()

	if ok {
		uc.schedule() // 释放资源后重新调度
		t.Stop()
	}
	return nil
}

func (uc *UseCase) CancelTask(id string) error {
	uc.mu.Lock()
	t, ok := uc.allTasks[id]
	if !ok {
		uc.mu.Unlock()
		return fmt.Errorf("task not found")
	}
	// 释放资源
	if members, exists := uc.allocatedMembers[id]; exists {
		uc.idleMembers = append(uc.idleMembers, members...)
		delete(uc.allocatedMembers, id)
	}
	uc.mu.Unlock()

	uc.schedule()
	return t.Cancel()
}

// TriggerSchedule 手动触发一次调度逻辑
func (uc *UseCase) TriggerSchedule() {
	uc.schedule()
}

// GetTask 代理方法
func (uc *UseCase) GetTask(id string) (*task.Task, bool) {
	uc.mu.RLock()
	defer uc.mu.RUnlock()
	t, ok := uc.allTasks[id]
	return t, ok
}

// ListTasks 代理方法
func (uc *UseCase) ListTasks() []*task.Task {
	uc.mu.RLock()
	defer uc.mu.RUnlock()
	if len(uc.allTasks) == 0 {
		return nil
	}
	res := make([]*task.Task, 0, len(uc.allTasks))
	for _, v := range uc.allTasks {
		res = append(res, v)
	}
	// 按创建时间倒序排列
	sort.Slice(res, func(i, j int) bool {
		return res[i].GetCreatedAt().Unix() > res[j].GetCreatedAt().Unix()
	})
	return res
}

// InitMembers 初始化玩家资源
func (uc *UseCase) InitMembers(members []MemberInfo) {
	uc.mu.Lock()
	defer uc.mu.Unlock()
	uc.idleMembers = append([]MemberInfo{}, members...)
	uc.totalMemberCount = len(members)
}

// GetMemberStats 统计
func (uc *UseCase) GetMemberStats() (idle, allocated, total int) {
	uc.mu.RLock()
	defer uc.mu.RUnlock()
	allocatedCount := 0
	for _, m := range uc.allocatedMembers {
		allocatedCount += len(m)
	}
	return len(uc.idleMembers), allocatedCount, uc.totalMemberCount
}

// StartMemberLoader 启动定时加载玩家任务
// n: 间隔秒数, m: 每次加载个数, total: 最大总数
func (uc *UseCase) StartMemberLoader(ctx context.Context, n, m, total int) {
	if !openAutoLoads {
		return
	}

	ticker := time.NewTicker(time.Duration(n) * time.Second)
	defer ticker.Stop()

	loadedCount := 0
	for loadedCount < total {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			// 准备本次要加载的玩家名 (例如 member_1, member_2...)
			batch := make([]MemberInfo, 0, m)
			for i := 1; i <= m && loadedCount < total; i++ {
				loadedCount++
				batch = append(batch, MemberInfo{
					MemberName: fmt.Sprintf("member_%d", loadedCount),
					Balance:    10000,
				})
			}

			// 调用 Data 层进行批量 Upsert
			err := uc.memberRepo.BatchUpsertMembers(ctx, batch)
			if err != nil {
				if uc.log != nil {
					uc.log.Errorf("BatchUpsertMembers error: %v", err)
				}
				// 如果失败了，loadedCount 可能需要回滚或者重试，这里简化处理
				continue
			}

			// 更新到 UseCase 的空闲玩家池
			uc.mu.Lock()
			uc.idleMembers = append(uc.idleMembers, batch...)
			uc.totalMemberCount += len(batch)
			uc.mu.Unlock()

			if uc.log != nil {
				uc.log.Infof("Loaded %d members, total now: %d", len(batch), uc.totalMemberCount)
			}

			// 触发一次调度，尝试运行排队的任务
			uc.schedule()
		}
	}
	if uc.log != nil {
		uc.log.Infof("Member loading task completed.")
	}
}
