package biz

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/go-kratos/kratos/v2/log"
)

// MemberPool 玩家资源池，封装空闲/已分配成员的存储与操作
type MemberPool struct {
	mu sync.RWMutex

	idleMembers      []MemberInfo
	allocatedMembers map[string][]MemberInfo // taskID -> 分配给该任务的玩家
	totalMemberCount int
}

// NewMemberPool 创建玩家资源池
func NewMemberPool() *MemberPool {
	return &MemberPool{
		idleMembers:      make([]MemberInfo, 0),
		allocatedMembers: make(map[string][]MemberInfo),
	}
}

// AddIdle 将玩家加入空闲池
func (p *MemberPool) AddIdle(members []MemberInfo) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.idleMembers = append(p.idleMembers, members...)
	p.totalMemberCount += len(members)
}

// Init 初始化空闲池（替换现有）
func (p *MemberPool) Init(members []MemberInfo) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.idleMembers = append([]MemberInfo{}, members...)
	p.totalMemberCount = len(members)
}

// CanAllocate 是否有足够空闲玩家可分配
func (p *MemberPool) CanAllocate(count int) bool {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return len(p.idleMembers) >= count
}

// Allocate 为任务分配玩家，返回分配的成员；若不足则返回 nil
func (p *MemberPool) Allocate(taskID string, count int) []MemberInfo {
	p.mu.Lock()
	defer p.mu.Unlock()
	if len(p.idleMembers) < count {
		return nil
	}
	allocated := append([]MemberInfo{}, p.idleMembers[:count]...)
	p.idleMembers = p.idleMembers[count:]
	p.allocatedMembers[taskID] = allocated
	return allocated
}

// Release 释放任务占用的玩家回空闲池
func (p *MemberPool) Release(taskID string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if m, ok := p.allocatedMembers[taskID]; ok {
		p.idleMembers = append(p.idleMembers, m...)
		delete(p.allocatedMembers, taskID)
	}
}

// Stats 返回 idle 数、已分配总数、总玩家数
func (p *MemberPool) Stats() (idle, allocated, total int) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	allocatedCount := 0
	for _, m := range p.allocatedMembers {
		allocatedCount += len(m)
	}
	return len(p.idleMembers), allocatedCount, p.totalMemberCount
}

// StartLoader 启动后台加载玩家；onLoaded 每批加载后回调（如触发调度）
func (p *MemberPool) StartLoader(
	ctx context.Context,
	repo DataRepo,
	logHelper *log.Helper,
	intervalSec, batchSize, maxTotal int,
	onLoaded func(),
) {
	ticker := time.NewTicker(time.Duration(intervalSec) * time.Second)
	defer ticker.Stop()

	loadedCount := 0
	for loadedCount < maxTotal {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			batch := make([]MemberInfo, 0, batchSize)
			for i := 0; i < batchSize && loadedCount < maxTotal; i++ {
				loadedCount++
				batch = append(batch, MemberInfo{
					MemberName: fmt.Sprintf("member_%d", loadedCount),
					Balance:    10000,
				})
			}
			if err := repo.BatchUpsertMembers(ctx, batch); err != nil {
				if logHelper != nil {
					logHelper.Errorf("BatchUpsertMembers: %v", err)
				}
				continue
			}
			p.AddIdle(batch)
			if logHelper != nil {
				_, _, total := p.Stats()
				logHelper.Infof("Loaded %d members, total now: %d", len(batch), total)
			}
			if onLoaded != nil {
				onLoaded()
			}
		}
	}
	if logHelper != nil {
		logHelper.Info("Member loading completed.")
	}
}
