package user

import (
	"context"
	"fmt"
	"kratos-layout/internal/biz/game/base"
	"kratos-layout/internal/biz/task"
	"math/rand/v2"
	"sync/atomic"
	"time"

	v1 "kratos-layout/api/stress/v1"

	"github.com/go-kratos/kratos/v2/log"
)

const delayMills = 200 * time.Millisecond
const defaultMaxRetries = 5

// SessionState 用户会话内部状态机（不对外暴露在 proto 中）
type SessionState int32

const (
	SessionStateUnspecified SessionState = 0
	SessionStateIdle        SessionState = 1
	SessionStateLaunching   SessionState = 2
	SessionStateLoggingIn   SessionState = 3
	SessionStateBetting     SessionState = 4
	SessionStateBonusSelect SessionState = 5
	SessionStateCompleted   SessionState = 6
	SessionStateFailed      SessionState = 7
)

// Session 用户会话
type Session struct {
	// 身份信息
	UserID     int64
	MemberName string
	NickName   string
	GameID     int64
	TaskID     string

	// 状态和认证
	State SessionState
	Token string

	// 执行进度
	Process  int32
	Target   int32
	TryTimes int32

	// 奖励相关
	BonusSequence []int64
	// BonusIndex 对齐 go-rtp-tool 的 SeqX：先自增再取模（首次会取序列第 2 个元素）
	BonusIndex int

	// 统计信息
	TotalDuration int64 // 纳秒
	StepDuration  int64 // 纳秒
	BetOrderCount int64
	BetBonusCount int64

	// 错误和时间
	LastError string
	CreatedAt time.Time
	UpdatedAt time.Time

	// 运行时依赖
	Config *v1.TaskConfig
	Game   base.IGame
	Client *APIClient
	// protobuf 新格式游戏清单（只读）
	protobufGames map[int64]bool

	//ctx    context.Context
	//cancel context.CancelFunc
	task *task.Task
}

// NewSession 创建新会话
func NewSession(userID int64, memberName string, gameID int64, taskID string, task *task.Task, protobufGames map[int64]bool) *Session {
	now := time.Now()
	//ctx, cancel := context.WithCancel(context.Background())
	s := &Session{
		UserID:     userID,
		MemberName: memberName,
		NickName:   memberName,
		GameID:     gameID,
		TaskID:     taskID,
		State:      SessionStateIdle,
		CreatedAt:  now,
		UpdatedAt:  now,
		//ctx:        ctx,
		//cancel:     cancel,
		task:          task,
		protobufGames: protobufGames,
	}
	return s
}

// Execute 执行会话（对齐 go-rtp-tool 的简单循环）
func (s *Session) Execute(ctx context.Context, cfg *v1.TaskConfig, game base.IGame, secretProvider base.SecretProvider, logger log.Logger) error {
	if cfg == nil {
		return fmt.Errorf("task config is nil")
	}
	s.Config = cfg
	s.Game = game
	s.Client = NewAPIClient(DefaultHTTPClient(), secretProvider, game, s.protobufGames)

	// 初始化
	if atomic.LoadInt32(&s.Target) == 0 && cfg.TimesPerMember > 0 {
		atomic.StoreInt32(&s.Target, int32(cfg.TimesPerMember))
		s.initBonusSequence()
	}

	maxRetries := defaultMaxRetries
	for {

		// 检查任务状态实现取消
		if s.task.GetStatus() == v1.TaskStatus_TASK_CANCELLED {
			s.State = SessionStateFailed
			s.LastError = "task cancelled"
			return nil
		}

		// 阻塞等待实现暂停
		if err := s.task.WaitIfPaused(ctx); err != nil {
			return err
		}

		select {
		case <-ctx.Done():
			s.State = SessionStateFailed
			return ctx.Err()
		default:
		}

		if s.State == SessionStateCompleted || s.State == SessionStateFailed {
			break
		}

		err := s.executeStep(ctx)
		if err != nil {
			if !s.handleError(err, maxRetries) {
				return err
			}
		}
	}

	return nil
}

// executeStep 执行当前步骤
func (s *Session) executeStep(ctx context.Context) error {
	atomic.AddInt32(&s.TryTimes, 1)
	defer func() { s.UpdatedAt = time.Now() }()

	var err error
	switch s.State {
	case SessionStateIdle, SessionStateLaunching:
		var token string
		token, err = s.Client.Launch(ctx, s.Config, s.MemberName)
		if err == nil {
			s.Token, s.State = token, SessionStateLoggingIn
			atomic.StoreInt32(&s.TryTimes, 0)
		} else {
			// 对齐 go-rtp-tool：launch 业务码失败直接结束该用户（NextRequest=finish）
			if apiErr, ok := err.(*APIError); ok && apiErr.Op == "launch" {
				s.State = SessionStateFailed
			}
		}
	case SessionStateLoggingIn:
		var token string
		var freeData map[string]any
		token, freeData, err = s.Client.Login(ctx, s.Config, s.Token)
		if err == nil {
			s.Token = token
			s.State = SessionStateBetting
			if s.needBetBonusGated(freeData) {
				s.State = SessionStateBonusSelect
			}
			atomic.StoreInt32(&s.TryTimes, 0)
		}
	case SessionStateBetting:
		start := time.Now()
		var data map[string]any
		data, err = s.Client.BetOrder(ctx, s.Config, s.Token)
		if err == nil {
			atomic.AddInt64(&s.BetOrderCount, 1)
			duration := time.Since(start)
			atomic.AddInt64(&s.TotalDuration, duration.Nanoseconds())
			atomic.StoreInt64(&s.StepDuration, duration.Nanoseconds())

			isSpinOverResult := false
			// 对齐 go-rtp-tool：有 game 实例时只走 game 逻辑；否则走通用逻辑
			if s.Game != nil {
				if s.Game.IsSpinOver(data) {
					isSpinOverResult = true
					if atomic.AddInt32(&s.Process, 1) >= atomic.LoadInt32(&s.Target) {
						s.State = SessionStateCompleted
					}
				}
				if s.Game.NeedBetBonus(data) {
					s.State = SessionStateBonusSelect
				}
			} else {
				if isSpinOver(data) {
					isSpinOverResult = true
					if atomic.AddInt32(&s.Process, 1) >= atomic.LoadInt32(&s.Target) {
						s.State = SessionStateCompleted
					}
				}
				if s.needBetBonusGated(data) {
					s.State = SessionStateBonusSelect
				}
			}

			// 同步更新 Task 汇总统计信息
			if s.task != nil {
				s.task.AddBetOrder(duration, isSpinOverResult)
			}

			atomic.StoreInt32(&s.TryTimes, 0)
		} else {
			err = s.handleBetOrderError(err)
		}
	case SessionStateBonusSelect:
		start := time.Now()
		var res *BetBonusResult
		res, err = s.Client.BetBonus(ctx, s.Config, s.Token, s.pickBonusNum())
		if err == nil {
			atomic.AddInt64(&s.BetBonusCount, 1)
			duration := time.Since(start)
			atomic.AddInt64(&s.TotalDuration, duration.Nanoseconds())
			atomic.StoreInt64(&s.StepDuration, duration.Nanoseconds())

			if !res.NeedContinue {
				s.State = SessionStateBetting
			}

			// 同步更新 Task 汇总统计信息 (Bonus 不计入 process 进度，除非它本身被视为一次 spin 结束，但这里对齐 go-rtp-tool)
			if s.task != nil {
				s.task.AddBetBonus(duration, false)
			}

			atomic.StoreInt32(&s.TryTimes, 0)
		}
	case SessionStateCompleted, SessionStateFailed:
		return nil
	default:
		return fmt.Errorf("unknown state: %v", s.State)
	}
	return err
}

// handleBetOrderError 处理下注错误
func (s *Session) handleBetOrderError(err error) error {
	if betErr, ok := err.(*BetOrderError); ok {
		if betErr.SleepDuration > 0 {
			time.Sleep(betErr.SleepDuration)
		}
		if betErr.NeedRelaunch {
			s.State = SessionStateLaunching
			s.Token = ""
			return betErr
		}
		if betErr.NeedRelogin {
			s.State = SessionStateLoggingIn
			return betErr
		}
	}
	return err
}

// handleError 处理错误（对齐 go-rtp-tool：检查 TryTimes，超过则失败）
func (s *Session) handleError(err error, maxRetries int) bool {
	s.LastError = err.Error()
	s.UpdatedAt = time.Now()

	// 记录到 Task 汇总统计
	if s.task != nil {
		s.task.AddError(err.Error())
	}

	tryTimes := atomic.LoadInt32(&s.TryTimes)

	// 对齐 go-rtp-tool: if TryTimes > maxRetryTimes { return }
	if tryTimes > int32(maxRetries) {
		s.State = SessionStateFailed
		return false
	}

	// 对齐 go-rtp-tool：launch 返回业务码失败会直接 finish（不再重试），但 main 仍会 sleep DelayMills
	if apiErr, ok := err.(*APIError); ok && apiErr.Op == "launch" {
		time.Sleep(delayMills)
		s.State = SessionStateFailed
		return false
	}

	// BetOrderError 已经在 handleBetOrderError 中处理了状态转换
	if _, ok := err.(*BetOrderError); ok {
		time.Sleep(delayMills)
		return true
	}

	// 对齐 go-rtp-tool：所有失败统一 sleep
	time.Sleep(delayMills)
	return true
}

// 辅助方法
func (s *Session) initBonusSequence() {
	if s.Config == nil {
		return
	}
	bonusCfg := getBonusConfig(s.Config, s.GameID)
	if bonusCfg != nil && len(bonusCfg.BonusSequence) > 0 {
		s.BonusSequence = append([]int64{}, bonusCfg.BonusSequence...)
	}
}

func (s *Session) pickBonusNum() int64 {
	bonusCfg := getBonusConfig(s.Config, s.GameID)
	if bonusCfg == nil {
		return s.getNextBonus()
	}
	if bonusCfg.BonusNum > 0 {
		return bonusCfg.BonusNum
	}
	if len(bonusCfg.RandomNums) == 2 && bonusCfg.RandomNums[0] <= bonusCfg.RandomNums[1] {
		return bonusCfg.RandomNums[0] + rand.Int64N(bonusCfg.RandomNums[1]-bonusCfg.RandomNums[0]+1)
	}
	if len(bonusCfg.BonusSequence) > 0 {
		if len(s.BonusSequence) == 0 {
			s.BonusSequence = append([]int64{}, bonusCfg.BonusSequence...)
		}
		return s.getNextBonus()
	}
	return 1
}

func (s *Session) getNextBonus() int64 {
	if len(s.BonusSequence) == 0 {
		return 1
	}
	// 对齐 go-rtp-tool: SeqX++ ; idx := SeqX % len(seq)
	s.BonusIndex++
	idx := s.BonusIndex % len(s.BonusSequence)
	return s.BonusSequence[idx]
}

func getBonusConfig(cfg *v1.TaskConfig, gameID int64) *v1.BetBonusConfig {
	if cfg == nil {
		return nil
	}
	for _, b := range cfg.BetBonus {
		if b != nil && b.GameId == gameID {
			return b
		}
	}
	return nil
}

func needBetBonus(data map[string]any, game base.IGame) bool {
	if game != nil && game.NeedBetBonus(data) {
		return true
	}
	if data == nil {
		return false
	}
	if v, ok := data["bonusState"]; ok {
		return fmt.Sprintf("%v", v) == "1"
	}
	if rtp, ok := data["rtp"].(map[string]any); ok {
		if v, ok := rtp["bonusState"]; ok {
			return fmt.Sprintf("%v", v) == "1"
		}
	}
	return false
}

func isSpinOver(data map[string]any) bool {
	// 对齐 go-rtp-tool：nil map 不视为结束
	if data == nil {
		return false
	}
	if over, ok := data["isOver"].(bool); ok {
		return over
	}
	if rtp, ok := data["rtp"].(map[string]any); ok {
		if over, ok := rtp["isOver"].(bool); ok {
			return over
		}
	}
	win := fmt.Sprintf("%v", data["win"])
	freeNum := fmt.Sprintf("%v", data["freeNum"])
	return win == "0" && freeNum == "0"
}

// needBetBonusGated 对齐 go-rtp-tool 的 need_bonus gating：
// - 如果 game 实例存在：由 game.NeedBetBonus 决定（上层会优先走 game 分支）
// - 如果 game 实例不存在：只有当 task config 中存在该 game 的 bet_bonus 配置时，才根据 bonusState 判断
func (s *Session) needBetBonusGated(data map[string]any) bool {
	if s == nil || data == nil {
		return false
	}
	if s.Game != nil && s.Game.NeedBetBonus(data) {
		return true
	}
	if getBonusConfig(s.Config, s.GameID) == nil {
		return false
	}
	return needBetBonus(data, nil)
}

// GetProgress 获取进度
func (s *Session) GetProgress() (process, target int) {
	return int(atomic.LoadInt32(&s.Process)), int(atomic.LoadInt32(&s.Target))
}

// GetState 获取状态
func (s *Session) GetState() SessionState {
	return s.State
}

// GetToken 获取Token
func (s *Session) GetToken() string {
	return s.Token
}

// GetDurations 获取耗时
func (s *Session) GetDurations() (total, step time.Duration) {
	return time.Duration(atomic.LoadInt64(&s.TotalDuration)), time.Duration(atomic.LoadInt64(&s.StepDuration))
}

// GetBetOrderCount 获取下注次数
func (s *Session) GetBetOrderCount() int64 {
	return atomic.LoadInt64(&s.BetOrderCount)
}

// GetBetBonusCount 获取奖励次数
func (s *Session) GetBetBonusCount() int64 {
	return atomic.LoadInt64(&s.BetBonusCount)
}

// GetLastError 获取最后错误
func (s *Session) GetLastError() string {
	return s.LastError
}

// IsCompleted 检查是否完成
func (s *Session) IsCompleted() bool {
	return s.State == SessionStateCompleted || s.State == SessionStateFailed
}

// IsFailed 是否失败结束
func (s *Session) IsFailed() bool {
	return s.State == SessionStateFailed
}
