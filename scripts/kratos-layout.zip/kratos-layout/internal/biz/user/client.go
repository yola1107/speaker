package user

import (
	"bytes"
	"context"
	"crypto/md5"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	jsoniter "github.com/json-iterator/go"

	v1 "kratos-layout/api/stress/v1"
	"kratos-layout/internal/biz/game/base"
)

//var json = jsoniter.ConfigCompatibleWithStandardLibrary

var (
	defaultHTTPOnce sync.Once
	defaultHTTP     *http.Client

	// JSON 序列化/反序列化复用池，减少 GC 压力
	jsonBufferPool = sync.Pool{
		New: func() any {
			return &bytes.Buffer{}
		},
	}
	// 注意：jsoniter.Encoder/Decoder 不能复用，每次都需要重新创建
	// 但我们可以复用 buffer 来减少内存分配
	// Base64 解码使用 DecodeString，简单可靠，不需要 Pool
)

func DefaultHTTPClient() *http.Client {
	defaultHTTPOnce.Do(func() {
		defaultHTTP = &http.Client{
			Timeout: 30 * time.Second,
			Transport: &http.Transport{
				Proxy:           http.ProxyFromEnvironment,
				TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
				// 优化：基于实际 120ms 响应时间调整连接池
				// 3000 玩家 × 5 次/秒 = 15000 QPS
				// 15000 QPS × 120ms 响应时间 = 1800 个并发连接
				// 空闲连接数应该大于并发连接数，以应对突发流量和网络波动
				// 留出 40% 余量：1800 × 1.4 = 2520
				MaxIdleConns:        3000, // 总空闲连接数（1800并发 + 700余量）
				MaxIdleConnsPerHost: 2500, // 单个主机空闲连接数
				MaxConnsPerHost:     0,    // 0表示不限制并发连接数
				IdleConnTimeout:     60 * time.Second,
				DisableKeepAlives:   false,
				TLSHandshakeTimeout: 10 * time.Second,
				DialContext: (&net.Dialer{
					Timeout:   30 * time.Second,
					KeepAlive: 30 * time.Second,
					DualStack: true,
				}).DialContext,
				// 对齐 go-rtp-tool：关闭 TLSNextProto，减少额外开销（并禁用自动 HTTP/2）
				TLSNextProto: make(map[string]func(authority string, c *tls.Conn) http.RoundTripper),
			},
		}
	})
	return defaultHTTP
}

type APIClient struct {
	http   *http.Client
	secret base.SecretProvider
	game   base.IGame // 游戏实例，用于 protobuf 转换和 bonus 判断
	// protobuf 新格式游戏清单（只读，可为空）
	protobufGames map[int64]bool

	// Protobuf 转换缓存，避免重复转换
	protoConverterCache base.ProtobufConverter
}

func NewAPIClient(httpClient *http.Client, secretProvider base.SecretProvider, game base.IGame, protobufGames map[int64]bool) *APIClient {
	if httpClient == nil {
		httpClient = DefaultHTTPClient()
	}
	return &APIClient{
		http:          httpClient,
		secret:        secretProvider,
		game:          game,
		protobufGames: protobufGames,
	}
}

func (c *APIClient) requireProtobuf(gameID int64) bool {
	// 如果配置了列表，则以配置为准；否则用 converter 是否存在兜底
	if c != nil && len(c.protobufGames) > 0 {
		return c.protobufGames[gameID]
	}
	if c != nil && c.game != nil && c.game.GetProtobufConverter() != nil {
		return true
	}
	return false
}

// APIError 用于区分“接口业务码失败”和网络/解码错误，便于上层做与 go-rtp-tool 一致的状态决策。
// Error 文本保持稳定，避免影响现有日志/统计。
type APIError struct {
	Op   string
	Code int
	Msg  string
}

func (e *APIError) Error() string {
	// 对齐旧实现的报错文本："<op> error: <code> <msg>"
	return fmt.Sprintf("%s error: %d %s", e.Op, e.Code, e.Msg)
}

type launchParams struct {
	GameID    int64  `json:"gameId"`
	Merchant  string `json:"merchant"`
	Member    string `json:"member"`
	Timestamp int64  `json:"timestamp"`
}

func signForLaunch(params launchParams, secret string) string {
	sign := fmt.Sprintf("%d%s%s%d%s", params.Timestamp, params.Merchant, params.Member, params.GameID, secret)
	h := md5.New()
	h.Write([]byte(sign))
	return fmt.Sprintf("%x", h.Sum(nil))
}

type apiResponse struct {
	Code int                 `json:"code"`
	Msg  string              `json:"msg"`
	Data jsoniter.RawMessage `json:"data"`
	// For BetOrder
	Bytes string `json:"bytes,omitempty"`
	Type  int    `json:"type,omitempty"`
}

func (c *APIClient) request(ctx context.Context, method, apiURL string, body any, token string, sign bool, cfg *v1.TaskConfig) (*apiResponse, error) {
	var bodyReader io.Reader
	if body != nil {
		// 使用复用 buffer，减少内存分配
		buf := jsonBufferPool.Get().(*bytes.Buffer)
		defer func() {
			buf.Reset()
			jsonBufferPool.Put(buf)
		}()

		// jsoniter.Encoder 每次都需要重新创建，不能复用
		encoder := jsoniter.NewEncoder(buf)
		if err := encoder.Encode(body); err != nil {
			return nil, err
		}
		// 优化：http.Do 会立即读取 bodyReader，所以 buf 的 Reset（在 defer 中）不会影响读取
		// 为了性能，不复制数据，直接使用 buf.Bytes()
		bodyReader = bytes.NewReader(buf.Bytes())
	}

	req, err := http.NewRequestWithContext(ctx, method, apiURL, bodyReader)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		if strings.Contains(apiURL, "/v1/game/launch") {
			// Launch doesn't usually use x-token, but if we need it...
		} else {
			req.Header.Set("x-token", token)
		}
	}

	if sign && cfg != nil {
		if lp, ok := body.(launchParams); ok {
			// 对齐 go-rtp-tool：缺 secret 直接报错；同时避免 secretProvider=nil 时 panic
			if c.secret == nil {
				return nil, errors.New("sign_required=true but secret provider is nil")
			}
			secret, ok := c.secret(cfg.Merchant)
			if !ok || secret == "" {
				return nil, fmt.Errorf("sign_required=true but no secret for merchant=%s", cfg.Merchant)
			}
			req.Header.Set("Sign", signForLaunch(lp, secret))
		}
	}

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		io.Copy(io.Discard, resp.Body)
		return nil, fmt.Errorf("http status %d", resp.StatusCode)
	}

	// jsoniter.Decoder 每次都需要重新创建，不能复用
	// 但我们可以直接使用 jsoniter 的流式 API
	var res apiResponse
	decoder := jsoniter.NewDecoder(resp.Body)
	if err := decoder.Decode(&res); err != nil {
		return nil, err
	}
	return &res, nil
}

func (c *APIClient) Launch(ctx context.Context, cfg *v1.TaskConfig, member string) (string, error) {
	params := launchParams{
		GameID:    cfg.GameId,
		Merchant:  cfg.Merchant,
		Member:    member,
		Timestamp: time.Now().Unix(),
	}
	apiURL := fmt.Sprintf("%s/v1/game/launch", strings.TrimRight(cfg.LaunchUrl, "/"))
	res, err := c.request(ctx, http.MethodPost, apiURL, params, "", cfg.SignRequired, cfg)
	if err != nil {
		return "", err
	}
	if res.Code != 0 {
		return "", &APIError{Op: "launch", Code: res.Code, Msg: res.Msg}
	}

	var data struct {
		LaunchUrl string `json:"launchUrl"`
	}
	// 优化：使用流式 API
	decoder := jsoniter.NewDecoder(bytes.NewReader(res.Data))
	_ = decoder.Decode(&data)

	// 对齐 go-rtp-tool：QueryUnescape 后再 Parse，避免 token 解析失败
	path, _ := url.QueryUnescape(data.LaunchUrl)
	parsed, err := url.Parse(path)
	if err != nil {
		return "", err
	}
	tk := parsed.Query().Get("token")
	if tk == "" {
		return "", errors.New("empty token")
	}
	return strings.ReplaceAll(tk, " ", "+"), nil
}

func (c *APIClient) Login(ctx context.Context, cfg *v1.TaskConfig, token string) (string, map[string]any, error) {
	apiURL := fmt.Sprintf("%s/api/member/login", strings.TrimRight(cfg.ApiUrl, "/"))
	res, err := c.request(ctx, http.MethodPost, apiURL, map[string]any{"token": token}, "", false, nil)
	if err != nil {
		return "", nil, err
	}
	if res.Code != 0 {
		return "", nil, fmt.Errorf("login error: %s", res.Msg)
	}

	var data struct {
		Token    string         `json:"token"`
		FreeData map[string]any `json:"freeData"`
	}
	// 优化：使用流式 API
	decoder := jsoniter.NewDecoder(bytes.NewReader(res.Data))
	_ = decoder.Decode(&data)

	return strings.ReplaceAll(data.Token, " ", "+"), data.FreeData, nil
}

// BetOrderError 细化错误类型，便于状态机判断是否需要重启
type BetOrderError struct {
	Code          int
	Msg           string
	NeedRelogin   bool          // 需要重新登录（回到 login）
	NeedRelaunch  bool          // 需要重新启动（回到 launch）
	SleepDuration time.Duration // 错误后需要等待的时间
}

func (e *BetOrderError) Error() string {
	return fmt.Sprintf("betorder error: code=%d msg=%s", e.Code, e.Msg)
}

func (c *APIClient) BetOrder(ctx context.Context, cfg *v1.TaskConfig, token string) (map[string]any, error) {
	params := map[string]any{"gameId": cfg.GameId}
	if cfg.BetOrder != nil {
		params["baseMoney"] = cfg.BetOrder.BaseMoney
		params["multiple"] = cfg.BetOrder.Multiple
		params["purchase"] = cfg.BetOrder.Purchase
	}

	apiURL := fmt.Sprintf("%s/api/game/betorder", strings.TrimRight(cfg.ApiUrl, "/"))
	res, err := c.request(ctx, http.MethodPost, apiURL, params, token, false, nil)
	if err != nil {
		return nil, err
	}

	if res.Code != 0 {
		msg := strings.TrimSpace(res.Msg)
		e := &BetOrderError{Code: res.Code, Msg: msg}
		lmsg := strings.ToLower(msg)
		// 优化：减少字符串操作，使用 EqualFold 替代多次 Contains
		switch {
		case strings.Contains(lmsg, "连接失效") ||
			strings.Contains(lmsg, "internal error") ||
			strings.Contains(lmsg, "invalid token") ||
			strings.Contains(lmsg, "token expired") ||
			strings.Contains(lmsg, "unauthorized"):

			e.NeedRelaunch = true
			// 优化：使用 EqualFold 避免重复 ToLower + Contains
			if strings.Contains(lmsg, "internal error") {
				e.SleepDuration = time.Second
			}
		case strings.Contains(lmsg, "limit"):
			e.NeedRelogin = true
			e.SleepDuration = 3 * time.Second
		}
		return nil, e
	}

	// Protobuf 解析策略（对齐 go-rtp-tool）：
	// - 如果该 game 在 protobuf_game_ids 配置中，则必须走 protobuf；bytes 为空直接报错
	// - 未配置列表时：若 game 声明了 converter，则视为必须走 protobuf（兜底）
	// - 非必须时：bytes 存在则尝试按 protobuf 解码；否则走 JSON
	needPB := c.requireProtobuf(cfg.GameId)
	if needPB {
		if c.game == nil {
			return nil, fmt.Errorf("protobuf required but no game instance, game=%d", cfg.GameId)
		}
		// 使用缓存的 converter，避免重复调用 GetProtobufConverter
		if c.protoConverterCache == nil {
			c.protoConverterCache = c.game.GetProtobufConverter()
		}
		conv := c.protoConverterCache
		if conv == nil {
			return nil, fmt.Errorf("protobuf required but no converter for game %d", cfg.GameId)
		}
		if strings.TrimSpace(res.Bytes) == "" {
			return nil, fmt.Errorf("betorder api response bytes is empty for game %d", cfg.GameId)
		}
		// Base64 解码：使用 DecodeString 自动分配，简单可靠
		protoBytes, err := base64.StdEncoding.DecodeString(res.Bytes)
		if err != nil {
			return nil, fmt.Errorf("failed to decode base64 bytes: %v", err)
		}
		// 显式调用 converter，确保类型正确
		result, err := conv(protoBytes)
		if err != nil {
			return nil, err
		}
		return result, nil
	}
	if strings.TrimSpace(res.Bytes) != "" {
		if c.game == nil {
			return nil, fmt.Errorf("no game instance for protobuf response, game=%d", cfg.GameId)
		}
		// 使用缓存的 converter
		if c.protoConverterCache == nil {
			c.protoConverterCache = c.game.GetProtobufConverter()
		}
		conv := c.protoConverterCache
		if conv == nil {
			return nil, fmt.Errorf("no converter for game %d", cfg.GameId)
		}
		// Base64 解码：使用 DecodeString 自动分配，简单可靠
		protoBytes, err := base64.StdEncoding.DecodeString(res.Bytes)
		if err != nil {
			return nil, fmt.Errorf("failed to decode base64 bytes: %v", err)
		}
		// 显式调用 converter，确保类型正确
		result, err := conv(protoBytes)
		if err != nil {
			return nil, err
		}
		return result, nil
	}

	var data map[string]any
	// 优化：使用流式 API，避免重复解析
	decoder := jsoniter.NewDecoder(bytes.NewReader(res.Data))
	_ = decoder.Decode(&data)
	return data, nil
}

// BetBonusResult 返回结果
type BetBonusResult struct {
	Data         map[string]any
	NeedContinue bool
}

func (c *APIClient) BetBonus(ctx context.Context, cfg *v1.TaskConfig, token string, bonusNum int64) (*BetBonusResult, error) {
	params := map[string]any{"gameId": cfg.GameId, "bonusNum": bonusNum}
	apiURL := fmt.Sprintf("%s/api/game/betbonus", strings.TrimRight(cfg.ApiUrl, "/"))
	res, err := c.request(ctx, http.MethodPost, apiURL, params, token, false, nil)
	if err != nil {
		return nil, err
	}
	if res.Code != 0 {
		return nil, fmt.Errorf("betbonus error: %d %s", res.Code, res.Msg)
	}

	var data map[string]any
	// 优化：使用流式 API，避免重复解析
	decoder := jsoniter.NewDecoder(bytes.NewReader(res.Data))
	_ = decoder.Decode(&data)
	result := &BetBonusResult{Data: data}
	if c.game != nil {
		if bi := c.game.AsBonusInterface(); bi != nil {
			result.NeedContinue = bi.BonusNextState(data)
		}
	}
	return result, nil
}
