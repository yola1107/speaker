package biz

import (
	"context"
	"fmt"
	"sync"

	v1 "kratos-layout/api/stress/v1"
	"kratos-layout/internal/biz/task"
	"kratos-layout/internal/biz/user"
)

// schedule 核心调度；仅通过 TaskPool / MemberPool 接口编排
func (uc *UseCase) schedule() {
	mp := uc.memberPool
	tp := uc.taskPool

	for {
		taskID, t, ok := tp.PeekPending()
		if !ok {
			tp.DropPendingHead()
			if taskID == "" {
				break
			}
			continue
		}
		if t == nil || t.GetStatus() != v1.TaskStatus_TASK_PENDING {
			tp.DropPendingHead()
			continue
		}

		config := t.GetConfig()
		if config == nil {
			tp.DropPendingHead()
			continue
		}
		count := int(config.MemberCount)
		if !tp.DequeuePending(taskID) {
			continue
		}

		allocated := mp.Allocate(taskID, count)
		if allocated == nil {
			tp.RequeueAtHead(taskID)
			break
		}

		ids := make([]int64, 0, len(allocated))
		for _, m := range allocated {
			ids = append(ids, m.ID)
		}
		t.SetUserIDs(ids)

		if err := t.Start(); err == nil {
			go uc.runTaskSessions(t, allocated)
		} else {
			t.SetUserIDs(nil)
			mp.Release(taskID)
		}
	}
}

// runTaskSessions 运行压测 Session，结束释放成员并触发下一轮调度
func (uc *UseCase) runTaskSessions(t *task.Task, members []MemberInfo) {
	meta := t.MetaSnapshot()
	g, _ := uc.GetGame(meta.Config.GameId)
	sp := func(merchant string) (string, bool) { return "", false }

	monitorCtx, monitorCancel := context.WithCancel(t.Context())
	go t.Monitor(monitorCtx)

	checker := func(id int64) bool { return uc.gamePool.RequireProtobuf(id) }
	var wg sync.WaitGroup
	wg.Add(len(members))
	for _, m := range members {
		member := m
		sess := user.NewSession(member.ID, member.MemberName, meta.Config.GameId, meta.ID, t, checker)
		t.MarkMemberStart()
		if err := t.Submit(func() {
			defer wg.Done()
			defer func() { t.MarkMemberDone(sess.IsFailed()) }()
			_ = sess.Execute(t.Context(), meta.Config, g, sp, uc.logger)
		}); err != nil {
			wg.Done()
			t.MarkMemberDone(true)
		}
	}
	wg.Wait()

	monitorCancel()
	uc.memberPool.Release(meta.ID)

	if t.GetStatus() == v1.TaskStatus_TASK_RUNNING {
		t.SetStatus(v1.TaskStatus_TASK_COMPLETED)
	}
	t.Stop()
	uc.schedule()
}

// CreateWithRequestID 创建并尝试运行
func (uc *UseCase) CreateWithRequestID(ctx context.Context, description string, config *v1.TaskConfig) (*task.Task, error) {
	tp := uc.taskPool

	taskID := tp.NextTaskID(config.GameId)
	t, err := task.NewTask(taskID, description, config)
	if err != nil {
		return nil, err
	}
	tp.Add(t)
	uc.schedule()
	return t, nil
}

// DeleteTask 删除任务并释放成员
func (uc *UseCase) DeleteTask(id string) error {
	t, ok := uc.taskPool.Remove(id)
	if !ok {
		return nil
	}
	uc.memberPool.Release(id)
	uc.schedule()
	t.Stop()
	return nil
}

// CancelTask 取消任务并释放成员
func (uc *UseCase) CancelTask(id string) error {
	t, ok := uc.taskPool.Get(id)
	if !ok {
		return fmt.Errorf("task not found")
	}
	uc.memberPool.Release(id)
	uc.schedule()
	return t.Cancel()
}

// GetTask 按 ID 获取任务
func (uc *UseCase) GetTask(id string) (*task.Task, bool) {
	return uc.taskPool.Get(id)
}

// ListTasks 返回所有任务（已按创建时间倒序）
func (uc *UseCase) ListTasks() []*task.Task {
	return uc.taskPool.List()
}

// InitMembers 初始化玩家资源
func (uc *UseCase) InitMembers(members []MemberInfo) {
	uc.memberPool.Init(members)
}

// GetMemberStats 玩家池统计
func (uc *UseCase) GetMemberStats() (idle, allocated, total int) {
	return uc.memberPool.Stats()
}
