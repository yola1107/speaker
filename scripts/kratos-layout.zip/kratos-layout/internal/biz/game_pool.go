package biz

import (
	"sort"
	"sync"

	"kratos-layout/internal/biz/game/base"
)

// GamePool 游戏注册表
type GamePool struct {
	mu sync.RWMutex

	byID  map[int64]base.IGame
	list  []base.IGame
	usePB map[int64]bool // 使用 protobuf 的 gameID 集合，可为空
}

// NewGamePool 从注册列表构建；list 按 GameID 升序。usePB 按需配置。
func NewGamePool(instances []base.IGame) *GamePool {
	p := &GamePool{
		byID: make(map[int64]base.IGame),
		list: make([]base.IGame, 0, len(instances)),
		// usePB 未配置时为 nil，RequireProtobuf 恒为 false
	}
	for _, g := range instances {
		p.byID[g.GameID()] = g
		p.list = append(p.list, g)
	}
	sort.Slice(p.list, func(i, j int) bool {
		return p.list[i].GameID() < p.list[j].GameID()
	})
	return p
}

// Get 按 gameID 获取
func (p *GamePool) Get(gameID int64) (base.IGame, bool) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	g, ok := p.byID[gameID]
	return g, ok
}

// List 返回按 GameID 升序的副本
func (p *GamePool) List() []base.IGame {
	p.mu.RLock()
	defer p.mu.RUnlock()
	cpy := make([]base.IGame, len(p.list))
	copy(cpy, p.list)
	return cpy
}

// RequireProtobuf 是否配置为使用 protobuf；未配置时 false，由 Client 按 game 兜底
func (p *GamePool) RequireProtobuf(gameID int64) bool {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.usePB != nil && p.usePB[gameID]
}
