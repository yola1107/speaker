package g18890

import (
	"kratos-layout/internal/biz/game/base"
)

// Game 游戏18890的实现
// 通过嵌入 Default 自动继承所有默认行为，只需重写需要自定义的方法
type Game struct {
	base.Default
}

// New 创建游戏实例
func New(gameID int64, name string) base.IGame {
	return &Game{Default: base.NewBaseGame(gameID, name)}
}

// 如果需要重写某些方法，可以在这里添加
// 例如：
// func (g *Game) NeedBetBonus(freeData map[string]any) bool {
//     // 自定义逻辑
//     return true
// }
