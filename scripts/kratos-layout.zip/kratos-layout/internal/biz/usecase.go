package biz

import (
	"context"
	"sync"

	"kratos-layout/internal/biz/game/base"

	"github.com/go-kratos/kratos/v2/log"
)

var openAutoLoads = true

// DataRepo 玩家信息数据库接口
type DataRepo interface {
	BatchUpsertMembers(ctx context.Context, members []MemberInfo) error
	GetMemberCount(ctx context.Context) (int64, error)
}

// MemberInfo 玩家信息
type MemberInfo struct {
	ID         int64
	MemberName string
	Balance    float64
}

// UseCase 编排层：仅通过 GamePool / MemberPool / TaskPool 接口操作
type UseCase struct {
	repo   DataRepo
	logger log.Logger
	log    *log.Helper

	gamePool   *GamePool
	memberPool *MemberPool
	taskPool   *TaskPool
}

// NewUseCase 创建 UseCase，初始化 GamePool / 双池，并启动 member loader（若 openAutoLoads）
func NewUseCase(repo DataRepo, logger log.Logger) (*UseCase, func(), error) {
	uc := &UseCase{
		repo:       repo,
		logger:     logger,
		log:        log.NewHelper(logger),
		gamePool:   NewGamePool(gameInstances),
		memberPool: NewMemberPool(),
		taskPool:   NewTaskPool(),
	}

	cleanup := func() {}
	if openAutoLoads {
		loaderCtx, cancel := context.WithCancel(context.Background())
		var loaderWg sync.WaitGroup
		loaderWg.Add(1)
		go func() {
			defer loaderWg.Done()
			uc.memberPool.StartLoader(loaderCtx, repo, uc.log, 1, 10, 100, uc.schedule)
		}()
		cleanup = func() {
			cancel()
			loaderWg.Wait()
		}
	}
	return uc, cleanup, nil
}

// GetGame 按 gameID 获取游戏
func (uc *UseCase) GetGame(gameID int64) (base.IGame, bool) {
	return uc.gamePool.Get(gameID)
}

// ListGames 返回游戏列表副本（按 GameID 升序）
func (uc *UseCase) ListGames() []base.IGame {
	return uc.gamePool.List()
}
