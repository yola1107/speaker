package biz

import (
	"context"
	"sort"
	"sync"

	"kratos-layout/internal/biz/game/base"
	"kratos-layout/internal/biz/task"

	"github.com/go-kratos/kratos/v2/log"
)

// MemberRepo 玩家信息数据库接口
type MemberRepo interface {
	BatchUpsertMembers(ctx context.Context, members []MemberInfo) error
	GetMemberCount(ctx context.Context) (int64, error)
}

// MemberInfo 玩家信息
type MemberInfo struct {
	ID         int64
	MemberName string
	Balance    float64
}

type UseCase struct {
	mu sync.RWMutex

	memberRepo MemberRepo
	logger     log.Logger
	log        *log.Helper

	// Game资源与调度
	games     map[int64]base.IGame
	gamesList []base.IGame

	// DB玩家信息，需要加载出来压测
	idleMembers      []MemberInfo
	allocatedMembers map[string][]MemberInfo // key: taskID, value: 分配给该任务的玩家
	totalMemberCount int

	// 任务信息
	allTasks     map[string]*task.Task // taskID -> task
	counter      map[int64]int32       // gameID -> counter
	pendingQueue []string

	// 幂等去重：request_id -> task_id
	requestToTask map[string]string

	// protobuf 新格式游戏清单（当前不通过 conf 配置；仅作为共享只读 map）
	protobufGames map[int64]bool

	// 生命周期：member loader
	loaderCancel context.CancelFunc
	loaderWg     sync.WaitGroup
}

func NewUseCase(memberRepo MemberRepo, logger log.Logger) (*UseCase, func(), error) {
	uc := &UseCase{
		memberRepo:       memberRepo,
		logger:           logger,
		log:              log.NewHelper(logger),
		games:            make(map[int64]base.IGame),
		allTasks:         make(map[string]*task.Task),
		pendingQueue:     make([]string, 0),
		allocatedMembers: make(map[string][]MemberInfo),
		counter:          make(map[int64]int32),
		requestToTask:    make(map[string]string),
		protobufGames:    make(map[int64]bool),
	}
	uc.initGames()

	// 启动玩家自动加载任务（绑定生命周期）：每隔 1 秒加载 10 个，最多 100 个
	loaderCtx, cancel := context.WithCancel(context.Background())
	uc.loaderCancel = cancel
	uc.loaderWg.Add(1)
	go func() {
		defer uc.loaderWg.Done()
		uc.StartMemberLoader(loaderCtx, 1, 10, 100)
	}()

	cleanup := func() {
		if uc.loaderCancel != nil {
			uc.loaderCancel()
		}
		uc.loaderWg.Wait()
	}

	return uc, cleanup, nil
}

// initGames 初始化游戏列表
func (uc *UseCase) initGames() {
	if len(instances) == 0 {
		return
	}
	uc.gamesList = make([]base.IGame, 0, len(instances))
	for _, g := range instances {
		uc.games[g.GameID()] = g
		uc.gamesList = append(uc.gamesList, g)
	}
	sort.Slice(uc.gamesList, func(i, j int) bool {
		return uc.gamesList[i].GameID() < uc.gamesList[j].GameID()
	})
}

func (uc *UseCase) GetGame(gameID int64) (base.IGame, bool) {
	uc.mu.RLock()
	defer uc.mu.RUnlock()
	g, ok := uc.games[gameID]
	return g, ok
}

func (uc *UseCase) ListGames() []base.IGame {
	uc.mu.RLock()
	defer uc.mu.RUnlock()
	cpy := make([]base.IGame, len(uc.gamesList))
	copy(cpy, uc.gamesList)
	return cpy
}
