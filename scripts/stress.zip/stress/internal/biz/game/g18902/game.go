package game18902

import (
	"fmt"
	"stress/internal/biz/game/base"
)

//
//const GameId = 18902

//type Game struct {
//}
//
//func (g *Game) Name() string {
//	return "波塞冬之力"
//}

type Game struct {
	base.Default
}

func New() base.IGame {
	return &Game{Default: base.NewBaseGame(18902, "波塞冬之力")}
}

func (*Game) NeedBetBonus(freeData map[string]any) bool {
	nextState, ok := freeData["nextState"]
	if ok {
		if fmt.Sprintf("%v", nextState) == "11" {
			return true
		}
	}
	return false
}

func (*Game) IsSpinOver(data map[string]any) bool {

	freeNum := fmt.Sprintf("%v", data["free"])
	if freeNum == "0" {
		return true
	}

	return false
}

func (g *Game) BonusNextState(data map[string]any) bool {
	st, ok := data["state"]
	if !ok {
		return false
	}
	state := fmt.Sprintf("%v", st)
	if state != "11" {
		return false
	}
	nst, ok1 := data["nextState"]
	if ok1 {
		if fmt.Sprintf("%v", nst) == "0" {
			return true
		}
	}
	return false
}
