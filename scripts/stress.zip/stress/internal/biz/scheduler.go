package biz

import (
	"context"
	"fmt"
	"sync"
	"time"

	v1 "stress/api/stress/v1"
	"stress/internal/biz/task"
	"stress/internal/biz/user"
)

// Schedule 核心调度；仅通过 TaskPool / MemberPool 接口编排
func (uc *UseCase) Schedule() {
	mp := uc.memberPool
	tp := uc.taskPool

	for {
		taskID, t, ok := tp.PeekPending()
		if !ok {
			tp.DropPendingHead()
			if taskID == "" {
				break
			}
			continue
		}
		if t == nil || t.GetStatus() != v1.TaskStatus_TASK_PENDING {
			tp.DropPendingHead()
			continue
		}

		config := t.GetConfig()
		if config == nil {
			tp.DropPendingHead()
			continue
		}
		count := int(config.MemberCount)
		if !tp.DequeuePending(taskID) {
			continue
		}

		allocated := mp.Allocate(taskID, count)
		if allocated == nil {
			tp.RequeueAtHead(taskID)
			break
		}

		ids := make([]int64, 0, len(allocated))
		for _, m := range allocated {
			ids = append(ids, m.ID)
		}
		t.SetUserIDs(ids)

		if err := t.Start(); err == nil {
			go uc.runTaskSessions(t)
		} else {
			t.SetUserIDs(nil)
			mp.Release(taskID)
		}
	}
}

// runTaskSessions 运行压测 Session，结束释放成员并触发下一轮调度
func (uc *UseCase) runTaskSessions(t *task.Task) {
	meta := t.MetaSnapshot()
	members := uc.memberPool.GetAllocated(meta.ID)
	if len(members) == 0 {
		return
	}

	g, _ := uc.GetGame(meta.Config.GameId)
	sp := func(merchant string) (string, bool) { return "", false }

	monitorCtx, monitorCancel := context.WithCancel(t.Context())
	go t.Monitor(monitorCtx)

	checker := func(id int64) bool { return uc.gamePool.RequireProtobuf(id) }
	var wg sync.WaitGroup
	wg.Add(len(members))
	for _, m := range members {
		member := m
		sess := user.NewSession(member.ID, member.Name, meta.Config.GameId, meta.ID, t, checker)
		t.MarkMemberStart()
		if err := t.Submit(func() {
			defer wg.Done()
			defer func() { t.MarkMemberDone(sess.IsFailed()) }()
			_ = sess.Execute(t.Context(), meta.Config, g, sp)
		}); err != nil {
			wg.Done()
			t.MarkMemberDone(true)
		}
	}
	wg.Wait()

	monitorCancel()
	uc.memberPool.Release(meta.ID)

	if t.GetStatus() == v1.TaskStatus_TASK_RUNNING {
		t.SetStatus(v1.TaskStatus_TASK_COMPLETED)
		uc.CleanTestEnvironment(meta.ID)
	}
	t.Stop()
	uc.Schedule()
}

// CreateTask 创建并尝试运行
func (uc *UseCase) CreateTask(ctx context.Context, description string, config *v1.TaskConfig) (*task.Task, error) {
	tp := uc.taskPool

	taskID := tp.NextTaskID(config.GameId)
	t, err := task.NewTask(taskID, description, config)
	if err != nil {
		return nil, err
	}
	tp.Add(t)
	uc.Schedule()
	return t, nil
}

// DeleteTask 删除任务并释放成员
func (uc *UseCase) DeleteTask(id string) error {
	t, ok := uc.taskPool.Remove(id)
	if !ok {
		return nil
	}
	uc.memberPool.Release(id)
	uc.Schedule()
	t.Stop()
	return nil
}

// CancelTask 取消任务并释放成员
func (uc *UseCase) CancelTask(id string) error {
	t, ok := uc.taskPool.Get(id)
	if !ok {
		return fmt.Errorf("task not found")
	}
	uc.memberPool.Release(id)
	uc.Schedule()
	return t.Cancel()
}

// GetTask 按 ID 获取任务
func (uc *UseCase) GetTask(id string) (*task.Task, bool) {
	return uc.taskPool.Get(id)
}

// ListTasks 返回所有任务（已按创建时间倒序）
func (uc *UseCase) ListTasks() []*task.Task {
	return uc.taskPool.List()
}

// GetMemberStats 玩家池统计
func (uc *UseCase) GetMemberStats() (idle, allocated, total int) {
	return uc.memberPool.Stats()
}

// CleanTestEnvironment 清理测试环境，与 scripts/db-cleaner/clean.sh 一致：只删 Redis 中 site:* 的键（如 egame50001:*）
func (uc *UseCase) CleanTestEnvironment(taskID string) {
	if uc.c == nil || len(uc.c.Sites) == 0 {
		uc.log.Infof("[%s] no sites configured, skip cleanup", taskID)
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Minute)
	defer cancel()
	uc.log.Infof("[%s] cleaning Redis (site:*), sites=%v", taskID, uc.c.Sites)
	var wg sync.WaitGroup
	wg.Add(len(uc.c.Sites))
	for _, s := range uc.c.Sites {
		site := s
		go func() {
			defer wg.Done()
			if err := uc.repo.CleanRedisBySite(ctx, site, ""); err != nil {
				uc.log.Errorf("Redis cleanup failed (site=%s): %v", site, err)
			} else {
				uc.log.Infof("[%s] Redis cleanup done for site=%s", taskID, site)
			}
		}()
	}
	wg.Wait()
}
