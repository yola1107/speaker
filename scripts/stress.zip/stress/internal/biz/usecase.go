package biz

import (
	"context"
	"fmt"
	"stress/internal/biz/game"
	"stress/internal/biz/game/base"
	"stress/internal/biz/member"
	"stress/internal/biz/task"
	"stress/internal/conf"
	"sync"
	"time"

	"github.com/go-kratos/kratos/v2/log"
)

var openAutoLoads = true

// 成员加载器配置常量（填充空闲池用）
const (
	MemberLoadIntervalSec = 1
	MemberLoadBatchSize   = 1000
	MemberLoadMaxTotal    = 3000
)

// DataRepo 玩家信息数据库接口
type DataRepo interface {
	BatchUpsertMembers(ctx context.Context, members []member.Info) error
	GetMemberCount(ctx context.Context) (int64, error)

	// 数据清理方法，pattern 为 site:*（与 clean.sh 一致，merchant 参数保留未用）
	CleanRedisBySite(ctx context.Context, site, merchant string) error
	CleanGameOrderTable(ctx context.Context) error
	GetGameOrderCount(ctx context.Context) (int64, error)
}

// UseCase 编排层：仅通过 GamePool / MemberPool / TaskPool 接口操作
type UseCase struct {
	repo   DataRepo
	logger log.Logger
	log    *log.Helper
	c      *conf.Launch

	gamePool   *game.Pool
	taskPool   *task.Pool
	memberPool *member.Pool
}

// NewUseCase 创建 UseCase，初始化 GamePool / 双池，并启动 member loader（若 openAutoLoads）
func NewUseCase(repo DataRepo, logger log.Logger, c *conf.Launch) (*UseCase, func(), error) {
	uc := &UseCase{
		repo:       repo,
		logger:     logger,
		log:        log.NewHelper(logger),
		c:          c,
		gamePool:   game.NewPool(),
		taskPool:   task.NewTaskPool(),
		memberPool: member.NewMemberPool(),
	}

	cleanup := func() {}
	if openAutoLoads {
		loaderCtx, cancel := context.WithCancel(context.Background())
		var loaderWg sync.WaitGroup
		loaderWg.Add(1)
		go func() {
			defer loaderWg.Done()
			runMemberLoader(loaderCtx, repo, uc.memberPool, uc.log, uc.Schedule)
		}()
		cleanup = func() {
			cancel()
			loaderWg.Wait()
		}
	}
	return uc, cleanup, nil
}

// GetGame 按 gameID 获取游戏
func (uc *UseCase) GetGame(gameID int64) (base.IGame, bool) {
	return uc.gamePool.Get(gameID)
}

// ListGames 返回游戏列表副本（按 GameID 升序）
func (uc *UseCase) ListGames() []base.IGame {
	return uc.gamePool.List()
}

// runMemberLoader 定时生成成员、落库并加入空闲池，每批后调用 onLoaded（如 Schedule）
func runMemberLoader(ctx context.Context, repo DataRepo, pool *member.Pool, logHelper *log.Helper, onLoaded func()) {
	ticker := time.NewTicker(time.Duration(MemberLoadIntervalSec) * time.Second)
	defer ticker.Stop()

	loadedCount := 0
	for loadedCount < MemberLoadMaxTotal {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			batch := make([]member.Info, 0, MemberLoadBatchSize)
			for i := 0; i < MemberLoadBatchSize && loadedCount < MemberLoadMaxTotal; i++ {
				loadedCount++
				batch = append(batch, member.Info{
					Name:    fmt.Sprintf("%s%d", member.DefaultMemberNamePrefix, loadedCount+1000),
					Balance: 10000,
				})
			}
			if len(batch) == 0 {
				continue
			}
			if err := repo.BatchUpsertMembers(ctx, batch); err != nil {
				if logHelper != nil {
					logHelper.Errorf("BatchUpsertMembers: %v", err)
				}
				loadedCount -= len(batch)
				continue
			}
			pool.AddIdle(batch)
			if logHelper != nil {
				_, _, total := pool.Stats()
				logHelper.Infof("Loaded %d members, total now: %d", len(batch), total)
			}
			if onLoaded != nil {
				onLoaded()
			}
		}
	}
	if logHelper != nil {
		logHelper.Info("Member loading completed.")
	}
}
