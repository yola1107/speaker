package task

import (
	"context"
	"fmt"
	"math/rand/v2"
	"sync"
	"sync/atomic"
	"time"

	v1 "stress/api/stress/v1"
	"stress/internal/biz/game/base"
)

// Session 相关常量
const (
	delayMills        = 100 * time.Millisecond // 重试延迟
	defaultMaxRetries = 5                      // 最大重试次数
)

type SessionState int32

const (
	SessionStateLaunching   SessionState = 1
	SessionStateLoggingIn   SessionState = 2
	SessionStateBetting     SessionState = 3
	SessionStateBonusSelect SessionState = 4
	SessionStateCompleted   SessionState = 5
	SessionStateFailed      SessionState = 6
)

type Session struct {
	UserID     int64
	MemberName string

	State SessionState
	Token string
	mu    sync.RWMutex

	Process    int32
	TryTimes   int32
	bonusIndex int64

	LastError string
}

func NewSession(userID int64, memberName string) *Session {
	return &Session{
		UserID:     userID,
		MemberName: memberName,
		State:      SessionStateLaunching,
		Token:      "",
		Process:    0,
		TryTimes:   0,
		LastError:  "",
		bonusIndex: 0,
	}
}

// State 操作方法（线程安全）
func (s *Session) getState() SessionState {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.State
}

func (s *Session) setState(state SessionState) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.State = state
}

// Token 操作方法（线程安全）
func (s *Session) getToken() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.Token
}

func (s *Session) setToken(token string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Token = token
}

type sessionDeps struct {
	cfg      *v1.TaskConfig
	target   int32
	game     base.IGame
	bonusCfg *v1.BetBonusConfig
}

func (s *Session) Execute(ctx context.Context, client *APIClient, task *Task) error {
	cfg := task.GetConfig()
	if cfg == nil {
		return fmt.Errorf("INVALID_CONFIG: task config is nil")
	}

	bonusCfg := cfg.BetBonus
	if bonusCfg != nil && !bonusCfg.Enable {
		bonusCfg = nil
	}

	deps := &sessionDeps{
		cfg:      cfg,
		target:   cfg.TimesPerMember,
		game:     task.GetGame(),
		bonusCfg: bonusCfg,
	}

	maxRetries := defaultMaxRetries
	for {
		if state := s.getState(); state == SessionStateCompleted || state == SessionStateFailed {
			break
		}

		select {
		case <-ctx.Done():
			s.setState(SessionStateFailed)
			return ctx.Err()
		default:
		}

		if err := s.dispatch(ctx, client, task, deps); err != nil {
			if !s.handleError(ctx, err, maxRetries, task) {
				return err
			}
		}

		if task != nil && task.GetStatus() == v1.TaskStatus_TASK_CANCELLED {
			s.setState(SessionStateFailed)
			s.LastError = "task cancelled"
			return nil
		}
	}
	return nil
}

func (s *Session) dispatch(ctx context.Context, client *APIClient, task *Task, deps *sessionDeps) error {
	s.TryTimes++ // 每次尝试都增加，成功时归零

	switch s.getState() {
	case SessionStateLaunching:
		return s.handleLaunch(ctx, client, deps)
	case SessionStateLoggingIn:
		return s.handleLogin(ctx, client, deps)
	case SessionStateBetting:
		return s.handleBetting(ctx, client, task, deps)
	case SessionStateBonusSelect:
		return s.handleBonus(ctx, client, task, deps)
	default:
		return fmt.Errorf("unknown state: %v", s.getState())
	}
}

func (s *Session) handleLaunch(ctx context.Context, client *APIClient, deps *sessionDeps) error {
	token, err := client.Launch(ctx, deps.cfg, s.MemberName)
	if err != nil {
		return err
	}
	s.setToken(token)
	s.setState(SessionStateLoggingIn)
	s.TryTimes = 0
	return nil
}

func (s *Session) handleLogin(ctx context.Context, client *APIClient, deps *sessionDeps) error {
	token, freeData, err := client.Login(ctx, deps.cfg, s.getToken())
	if err != nil {
		return err
	}
	s.setToken(token)
	s.setState(SessionStateBetting)
	if s.checkNeedBonus(freeData, deps.game, deps.bonusCfg) {
		s.setState(SessionStateBonusSelect)
	}
	s.TryTimes = 0
	return nil
}

func (s *Session) handleBetting(ctx context.Context, client *APIClient, task *Task, deps *sessionDeps) error {
	start := time.Now()
	data, err := client.BetOrder(ctx, deps.cfg, s.getToken(), deps.game)
	if err != nil {
		return s.processBetOrderError(ctx, err)
	}

	duration := time.Since(start)
	spinOver := s.checkSpinOver(data, deps.game)
	if spinOver && atomic.AddInt32(&s.Process, 1) >= deps.target {
		s.setState(SessionStateCompleted)
	}
	if s.checkNeedBonus(data, deps.game, deps.bonusCfg) {
		s.setState(SessionStateBonusSelect)
	}
	if task != nil {
		task.AddBetOrder(duration, spinOver)
	}
	s.TryTimes = 0
	return nil
}

func (s *Session) processBetOrderError(ctx context.Context, err error) error {
	betErr, ok := err.(*BetOrderError)
	if !ok {
		return err
	}
	if betErr.SleepDuration > 0 {
		if !s.sleepOrCancel(ctx, betErr.SleepDuration) {
			return fmt.Errorf("bet order cancelled during sleep")
		}
	}
	if betErr.NeedRelaunch {
		s.setState(SessionStateLaunching)
		s.setToken("")
	} else if betErr.NeedRelogin {
		s.setState(SessionStateLoggingIn)
	}
	// 返回错误本身，让外层 handleError 决定重试逻辑
	return betErr
}

func (s *Session) handleBonus(ctx context.Context, client *APIClient, task *Task, deps *sessionDeps) error {
	start := time.Now()
	res, err := client.BetBonus(ctx, deps.cfg, s.getToken(), s.pickBonusNum(deps.bonusCfg), deps.game)
	if err != nil {
		return err
	}

	duration := time.Since(start)
	if !res.NeedContinue {
		s.setState(SessionStateBetting)
	}
	if task != nil {
		task.AddBetBonus(duration)
	}
	s.TryTimes = 0
	return nil
}

func (s *Session) handleError(ctx context.Context, err error, maxRetries int, task *Task) bool {
	errMsg := err.Error()
	if task != nil && s.LastError != errMsg {
		task.AddError()
	}
	s.LastError = errMsg

	if s.TryTimes > int32(maxRetries) {
		s.setState(SessionStateFailed)
		return false
	}

	// 某些错误类型不可重试或需要特殊处理
	if apiErr, ok := err.(*APIError); ok && apiErr.Op == "launch" {
		// Launch 业务失败通常不再重试（如配置错误）
		if !s.sleepOrCancel(ctx, delayMills) {
			return false
		}
		s.setState(SessionStateFailed)
		return false
	}

	if _, ok := err.(*BetOrderError); ok {
		// BetOrderError 已经在 processBetOrderError 中处理了状态变更（Relaunch/Relogin）
		// 这里主要负责决定是否继续循环
		// 如果状态已经变更为 Launching/LoggingIn，那么继续循环是合理的
		// 只要没超过 maxRetries
		return true
	}

	// 默认休眠重试
	if !s.sleepOrCancel(ctx, delayMills) {
		return false
	}
	return true
}

func (s *Session) sleepOrCancel(ctx context.Context, duration time.Duration) bool {
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-timer.C:
		return true
	case <-ctx.Done():
		s.setState(SessionStateFailed)
		return false
	}
}

func (s *Session) pickBonusNum(bonusCfg *v1.BetBonusConfig) int64 {
	if bonusCfg == nil {
		return s.getNextBonus(nil)
	}
	if bonusCfg.BonusNum > 0 {
		return bonusCfg.BonusNum
	}
	if len(bonusCfg.RandomNums) == 2 && bonusCfg.RandomNums[0] <= bonusCfg.RandomNums[1] {
		return bonusCfg.RandomNums[0] + rand.Int64N(bonusCfg.RandomNums[1]-bonusCfg.RandomNums[0]+1)
	}
	if len(bonusCfg.BonusSequence) > 0 {
		return s.getNextBonus(bonusCfg)
	}
	return 1
}

func (s *Session) getNextBonus(bonusCfg *v1.BetBonusConfig) int64 {
	if bonusCfg == nil || len(bonusCfg.BonusSequence) == 0 {
		return 1
	}
	seq := bonusCfg.BonusSequence
	newIndex := atomic.AddInt64(&s.bonusIndex, 1)
	idx := int(newIndex) % len(seq)
	return seq[idx]
}

func (s *Session) checkSpinOver(data map[string]any, game base.IGame) bool {
	if game != nil {
		return game.IsSpinOver(data)
	}
	return false
}

func (s *Session) checkNeedBonus(data map[string]any, game base.IGame, bonusCfg *v1.BetBonusConfig) bool {
	if game != nil && game.NeedBetBonus(data) {
		return true
	}
	return false
}

func (s *Session) IsFailed() bool {
	return s.getState() == SessionStateFailed
}
