package task

import (
	"context"
	"net/http"
	"runtime"
	"runtime/debug"
	"sync"
	"time"

	v1 "stress/api/stress/v1"
	"stress/internal/biz/chart"
	"stress/internal/biz/member"
	"stress/internal/biz/metrics"
	"stress/internal/conf"
	"stress/internal/notify"

	"github.com/panjf2000/ants/v2"
)

// ExecDeps 任务执行依赖
type ExecDeps struct {
	Repo       OrderRepo
	MemberPool MemberReleaser
	Conf       *conf.Stress
	Notify     notify.Notifier
	Chart      chart.IGenerator
	OnComplete func() // cleanup 完成后回调，用于唤醒调度器
}

// OrderRepo 订单数据接口
type OrderRepo interface {
	GetGameOrderCount(ctx context.Context) (int64, error)
	GetDetailedOrderAmounts(ctx context.Context, scope OrderScope) (totalBet, totalWin, betOrderCount, bonusOrderCount int64, err error)
	QueryGameOrderPoints(ctx context.Context, scope OrderScope) ([]chart.Point, error)
	UploadBytes(ctx context.Context, bucket, key, contentType string, data []byte) (string, error)
	CleanRedisBySites(ctx context.Context, sites []string) error
	DeleteOrdersByScope(ctx context.Context, scope OrderScope) (int64, error)
}

// MemberReleaser 成员释放接口
type MemberReleaser interface {
	Release(taskID string)
}

type MemberInfo = member.Info

type OrderScope struct {
	GameID     int64
	Merchant   string
	StartTime  time.Time
	EndTime    time.Time
	ExcludeAmt float64
}

type taskResources struct {
	httpClient *http.Client
	apiClient  *APIClient
	antsPool   *ants.Pool
}

// Execute 执行任务 - 线性化流程
func (t *Task) Execute(members []MemberInfo, deps *ExecDeps) {
	if !t.CompareAndSetStatus(v1.TaskStatus_TASK_PENDING, v1.TaskStatus_TASK_RUNNING) {
		t.log.Warnf("[%s] task status changed, skip execution", t.GetID())
		return
	}

	t.SetStartAt()
	capacity := len(members)
	t.AddActive(int64(capacity))

	// 1. 初始化资源
	res := t.initResources(capacity, deps)
	// 确保无论如何都会清理资源
	defer t.cleanup(deps, res)

	// 2. 启动后台监控
	stopMonitor := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		t.runMonitor(stopMonitor)
	}()
	go func() {
		defer wg.Done()
		t.runPeriodicReporting(deps, stopMonitor)
	}()

	// 3. 执行核心压测会话
	t.runSessions(members, res.apiClient, res.antsPool)

	// 4. 停止任务状态（防止新 Session 启动，虽然 runSessions 已结束）
	t.Stop()

	// 5. 等待订单写入（同步阻塞）
	t.monitorOrderWrite(deps)
	t.SetFinishAt()

	// 6. 停止后台监控
	close(stopMonitor)
	wg.Wait()

	// 7. 最终上报与数据处理
	t.finalize(deps)
}

func (t *Task) initResources(capacity int, deps *ExecDeps) *taskResources {
	httpClient := NewHTTPClient(capacity)
	apiClient := NewAPIClient(httpClient, nil, deps.Conf.Launch)
	antsPool, _ := ants.NewPool(capacity)
	return &taskResources{
		httpClient: httpClient,
		apiClient:  apiClient,
		antsPool:   antsPool,
	}
}

func (t *Task) runSessions(members []MemberInfo, apiClient *APIClient, antsPool *ants.Pool) {
	var wg sync.WaitGroup
	submitErrCount := 0

	for _, m := range members {
		m := m
		sess := NewSession(m.ID, m.Name)
		wg.Add(1)
		if err := antsPool.Submit(func() {
			defer wg.Done()
			defer t.MarkSessionDone(!sess.IsFailed())
			_ = sess.Execute(t.Context(), apiClient, t)
		}); err != nil {
			wg.Done()
			t.MarkSessionDone(false)
			submitErrCount++
		}
	}

	if submitErrCount > 0 {
		t.log.Infof("[%s] failed to submit %d sessions to ants pool", t.GetID(), submitErrCount)
	}

	wg.Wait()
	if t.Context().Err() != nil {
		t.log.Infof("[%s] runSessions cancelled", t.GetID())
	}
}

func (t *Task) runMonitor(stop <-chan struct{}) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-stop:
			return
		case <-ticker.C:
			t.LogProgress(false)
		}
	}
}

func (t *Task) runPeriodicReporting(deps *ExecDeps, stop <-chan struct{}) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	// 立即上报一次初始状态
	t.report(deps, false)

	for {
		select {
		case <-stop:
			return
		case <-ticker.C:
			t.report(deps, false)
		}
	}
}

func (t *Task) monitorOrderWrite(deps *ExecDeps) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()

	// 最多等待 5 分钟 (60 * 5s)
	for i := 0; i < 60; i++ {
		if orderCount, err := deps.Repo.GetGameOrderCount(context.Background()); err == nil && orderCount >= t.GetStep() {
			return
		}
		<-ticker.C
	}
	t.log.Warnf("[%s] monitorOrderWrite timeout", t.GetID())
}

func (t *Task) finalize(deps *ExecDeps) {
	// 如果任务仍在运行中（未被取消），标记为处理中（等待生成报告）
	t.CompareAndSetStatus(v1.TaskStatus_TASK_RUNNING, v1.TaskStatus_TASK_PROCESSING)
	// 最终上报
	t.report(deps, true)
}

func (t *Task) report(deps *ExecDeps, completed bool) {
	ctx := context.Background()
	rpt := t.Snapshot(time.Now())

	scope := t.buildOrderScope(deps)
	if totalBet, totalWin, betOrderCount, _, err := deps.Repo.GetDetailedOrderAmounts(ctx, scope); err == nil {
		rpt.TotalBet, rpt.TotalWin, rpt.OrderCount = totalBet, totalWin, betOrderCount
		if totalBet > 0 {
			rpt.RtpPct = float64(totalWin*100) / float64(totalBet)
		}
	} else if orderCount, err := deps.Repo.GetGameOrderCount(ctx); err == nil {
		rpt.OrderCount = orderCount
	}

	metrics.ReportTask(rpt)

	if completed {
		t.handleCompletion(deps, ctx, rpt, scope)
	}
}

func (t *Task) handleCompletion(deps *ExecDeps, ctx context.Context, report *v1.TaskCompletionReport, scope OrderScope) {
	t.SetStatus(v1.TaskStatus_TASK_PROCESSING)
	defer t.SetStatus(v1.TaskStatus_TASK_COMPLETED)

	t.uploadChart(deps, ctx, report, scope)
	t.sendNotification(deps, ctx, report)
	t.cleanupEnvironment(deps, ctx, scope)

	t.log.Infof("[%s] task completed, use=%v", t.GetID(), time.Since(t.GetStartAt()))
}

func (t *Task) buildOrderScope(deps *ExecDeps) OrderScope {
	cfg := t.GetConfig()
	excludeAmt := 0.0
	if cfg.BetOrder != nil {
		excludeAmt = cfg.BetOrder.BaseMoney
	}

	scope := OrderScope{
		GameID:     cfg.GameId,
		Merchant:   deps.Conf.Launch.Merchant,
		StartTime:  t.GetStartAt(),
		EndTime:    t.GetFinishedAt(),
		ExcludeAmt: excludeAmt,
	}
	if scope.EndTime.IsZero() {
		scope.EndTime = time.Now()
	}
	return scope
}

func (t *Task) uploadChart(deps *ExecDeps, ctx context.Context, report *v1.TaskCompletionReport, scope OrderScope) {
	if deps.Chart == nil || (!deps.Conf.Chart.GenerateLocal && !deps.Conf.Chart.UploadToS3) {
		return
	}

	pts, err := deps.Repo.QueryGameOrderPoints(ctx, scope)
	if err != nil {
		t.log.Errorf("failed to query game order points: %v", err)
		return
	}

	result, err := deps.Chart.Generate(pts, report.TaskId, report.GameName, scope.Merchant, deps.Conf.Chart.GenerateLocal)
	if err != nil {
		t.log.Errorf("failed to generate chart: %v", err)
		return
	}

	if !deps.Conf.Chart.UploadToS3 {
		return
	}

	htmlKey := "charts/" + report.TaskId + ".html"
	htmlUrl, err := deps.Repo.UploadBytes(ctx, "", htmlKey, "text/html; charset=utf-8", []byte(result.HTMLContent))
	if err != nil {
		t.log.Errorf("failed to upload HTML to S3: %v", err)
		return
	}
	t.SetRecordUrl(htmlUrl)
	report.Url = htmlUrl

	result.HTMLContent = ""
	runtime.GC()
}

func (t *Task) sendNotification(deps *ExecDeps, ctx context.Context, report *v1.TaskCompletionReport) {
	if deps.Notify == nil || !deps.Conf.Notify.Enabled {
		return
	}
	msg := notify.BuildTaskCompletionMessage(report)
	if err := deps.Notify.Send(ctx, msg); err != nil {
		t.log.Warnf("[%s] notify task completion: %v", report.TaskId, err)
	}
}

func (t *Task) cleanupEnvironment(deps *ExecDeps, ctx context.Context, scope OrderScope) {
	cleanupCtx, cancel := context.WithTimeout(ctx, 10*time.Minute)
	defer cancel()

	if err := deps.Repo.CleanRedisBySites(cleanupCtx, deps.Conf.Launch.Sites); err != nil {
		t.log.Errorf("[%s] Redis cleanup: %v", t.GetID(), err)
	}

	if _, err := deps.Repo.DeleteOrdersByScope(cleanupCtx, scope); err != nil {
		t.log.Errorf("[%s] Mysql delete orders: %v", t.GetID(), err)
	}
}

func (t *Task) cleanup(deps *ExecDeps, res *taskResources) {
	if res.httpClient != nil {
		res.httpClient.CloseIdleConnections()
		time.Sleep(200 * time.Millisecond)
		res.httpClient.CloseIdleConnections()
		if transport, ok := res.httpClient.Transport.(*http.Transport); ok {
			transport.CloseIdleConnections()
			res.httpClient.Transport = nil
		}
	}

	if res.apiClient != nil {
		res.apiClient.Close()
	}

	if res.antsPool != nil {
		res.antsPool.Release()
	}

	deps.MemberPool.Release(t.GetID())

	t.mu.Lock()
	t.game = nil
	t.mu.Unlock()

	reclaimMemory()

	if deps.OnComplete != nil {
		deps.OnComplete()
	}
}

func reclaimMemory() {
	runtime.GC()
	time.Sleep(50 * time.Millisecond)
	runtime.GC()
	debug.FreeOSMemory()
}
