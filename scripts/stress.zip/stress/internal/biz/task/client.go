package task

import (
	"bytes"
	"context"
	"crypto/md5"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	v1 "stress/api/stress/v1"
	"stress/internal/biz/game/base"
	"stress/internal/conf"

	jsoniter "github.com/json-iterator/go"
)

var (
	jsonAPI = jsoniter.ConfigFastest

	jsonBufferPool = sync.Pool{
		New: func() any {
			return &bytes.Buffer{}
		},
	}

	relaunchKeywords = []string{"连接失效", "internal error", "invalid token", "token expired", "unauthorized"}
)

const maxConnsCap = 10000

// NewHTTPClient 按任务人数创建 HTTP 客户端
func NewHTTPClient(maxConns int) *http.Client {
	if maxConns <= 0 {
		maxConns = 100
	}
	if maxConns > maxConnsCap {
		maxConns = maxConnsCap
	}
	return &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			Proxy:               http.ProxyFromEnvironment,
			TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
			MaxIdleConns:        maxConns,
			MaxIdleConnsPerHost: maxConns,
			MaxConnsPerHost:     maxConns,
			IdleConnTimeout:     45 * time.Second,
			DisableKeepAlives:   false,
			ForceAttemptHTTP2:   true,
			TLSHandshakeTimeout: 5 * time.Second,
			DialContext: (&net.Dialer{
				Timeout:   10 * time.Second,
				KeepAlive: 30 * time.Second,
				DualStack: true,
			}).DialContext,
			ResponseHeaderTimeout: 10 * time.Second,
			ExpectContinueTimeout: 1 * time.Second,
		},
	}
}

// APIError 统一的 API 错误类型
type APIError struct {
	Op   string
	Code int
	Msg  string
}

func (e *APIError) Error() string {
	return fmt.Sprintf("api error: op=%s code=%d msg=%s", e.Op, e.Code, e.Msg)
}

// BetOrderError 下注特定错误
type BetOrderError struct {
	Code          int
	Msg           string
	NeedRelogin   bool
	NeedRelaunch  bool
	SleepDuration time.Duration
}

func (e *BetOrderError) Error() string {
	return fmt.Sprintf("betorder error: code=%d msg=%s", e.Code, e.Msg)
}

type APIClient struct {
	http          *http.Client
	secret        base.SecretProvider
	baseApiURL    string
	baseLaunchURL string
	merchant      string
	signRequired  bool
}

func NewAPIClient(httpClient *http.Client, secretProvider base.SecretProvider,
	launchCfg *conf.Stress_Launch) *APIClient {
	return &APIClient{
		http:          httpClient,
		secret:        secretProvider,
		baseApiURL:    strings.TrimRight(launchCfg.GetApiUrl(), "/"),
		baseLaunchURL: strings.TrimRight(launchCfg.GetLaunchUrl(), "/"),
		merchant:      launchCfg.GetMerchant(),
		signRequired:  launchCfg.GetSignRequired(),
	}
}

type launchParams struct {
	GameID    int64  `json:"gameId"`
	Merchant  string `json:"merchant"`
	Member    string `json:"member"`
	Timestamp int64  `json:"timestamp"`
}

func signForLaunch(params launchParams, secret string) string {
	sign := fmt.Sprintf("%d%s%s%d%s", params.Timestamp, params.Merchant, params.Member, params.GameID, secret)
	h := md5.New()
	h.Write([]byte(sign))
	return fmt.Sprintf("%x", h.Sum(nil))
}

type apiResponse struct {
	Code  int                 `json:"code"`
	Msg   string              `json:"msg"`
	Data  jsoniter.RawMessage `json:"data"`
	Bytes string              `json:"bytes,omitempty"`
}

// postGeneric 发送 POST 请求并解析响应数据到 T
// 如果响应 Code != 0，返回 *APIError
func postGeneric[T any](c *APIClient, ctx context.Context, apiURL string, reqBody any, token string) (*T, error) {
	res, err := c.request(ctx, http.MethodPost, apiURL, reqBody, token, false, nil)
	if err != nil {
		return nil, err
	}
	if res.Code != 0 {
		return nil, &APIError{Op: "generic", Code: res.Code, Msg: res.Msg}
	}
	var data T
	if len(res.Data) > 0 {
		if err := jsonAPI.Unmarshal(res.Data, &data); err != nil {
			return nil, fmt.Errorf("unmarshal response data error: %w", err)
		}
	}
	return &data, nil
}

func (c *APIClient) request(ctx context.Context, method, apiURL string, body any, token string, sign bool, cfg *v1.TaskConfig) (*apiResponse, error) {
	var bodyReader io.Reader
	if body != nil {
		buf := jsonBufferPool.Get().(*bytes.Buffer)
		defer func() {
			buf.Reset()
			jsonBufferPool.Put(buf)
		}()

		encoder := jsonAPI.NewEncoder(buf)
		if err := encoder.Encode(body); err != nil {
			return nil, err
		}
		bodyReader = bytes.NewReader(buf.Bytes())
	}

	req, err := http.NewRequestWithContext(ctx, method, apiURL, bodyReader)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Connection", "keep-alive")
	if token != "" {
		req.Header.Set("x-token", token)
	}

	if sign && cfg != nil {
		if lp, ok := body.(launchParams); ok {
			if c.secret == nil {
				return nil, errors.New("sign_required=true but secret provider is nil")
			}
			secret, ok := c.secret(c.merchant)
			if !ok || secret == "" {
				return nil, fmt.Errorf("sign_required=true but no secret for merchant=%s", c.merchant)
			}
			req.Header.Set("Sign", signForLaunch(lp, secret))
		}
	}

	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		io.CopyN(io.Discard, resp.Body, 1024)
		return nil, fmt.Errorf("http status %d", resp.StatusCode)
	}

	var res apiResponse
	if err := jsonAPI.NewDecoder(resp.Body).Decode(&res); err != nil {
		return nil, err
	}
	return &res, nil
}

type LaunchResponse struct {
	LaunchUrl string `json:"launchUrl"`
}

func (c *APIClient) Launch(ctx context.Context, cfg *v1.TaskConfig, member string) (string, error) {
	params := launchParams{
		GameID:    cfg.GameId,
		Merchant:  c.merchant,
		Member:    member,
		Timestamp: time.Now().Unix(),
	}

	apiURL := c.baseLaunchURL + "/v1/game/launch"
	// Launch 比较特殊，需要签名，且我们不需要通用泛型封装里的 Code 检查逻辑（需要自定义Op名称），
	// 或者我们可以复用 request 直接处理。这里复用 request。
	res, err := c.request(ctx, http.MethodPost, apiURL, params, "", c.signRequired, cfg)
	if err != nil {
		return "", err
	}
	if res.Code != 0 {
		return "", &APIError{Op: "launch", Code: res.Code, Msg: res.Msg}
	}

	var data LaunchResponse
	if err := jsonAPI.Unmarshal(res.Data, &data); err != nil {
		return "", err
	}

	path, _ := url.QueryUnescape(data.LaunchUrl)
	parsed, err := url.Parse(path)
	if err != nil {
		return "", err
	}
	tk := parsed.Query().Get("token")
	if tk == "" {
		return "", errors.New("empty token from launch url")
	}
	return strings.ReplaceAll(tk, " ", "+"), nil
}

type LoginResponse struct {
	Token    string         `json:"token"`
	FreeData map[string]any `json:"freeData"`
}

func (c *APIClient) Login(ctx context.Context, cfg *v1.TaskConfig, token string) (string, map[string]any, error) {
	apiURL := c.baseApiURL + "/api/member/login"
	data, err := postGeneric[LoginResponse](c, ctx, apiURL, map[string]any{"token": token}, "")
	if err != nil {
		// 转换通用错误为带 Op 的错误，或者直接返回
		// 这里为了保持兼容性，还是返回 error
		// 之前的逻辑是返回 fmt.Errorf("login error: %s", res.Msg)
		// 现在的 postGeneric 返回 APIError，包含了 code 和 msg
		return "", nil, err
	}
	return strings.ReplaceAll(data.Token, " ", "+"), data.FreeData, nil
}

func (c *APIClient) decodeProtobuf(cfg *v1.TaskConfig, bytesData string, game base.IGame) (map[string]any, error) {
	bytesTrimmed := strings.TrimSpace(bytesData)
	if bytesTrimmed == "" {
		return nil, fmt.Errorf("betorder api response bytes is empty for game %d", cfg.GameId)
	}
	protoBytes, err := base64.StdEncoding.DecodeString(bytesTrimmed)
	if err != nil {
		return nil, fmt.Errorf("failed to decode base64 bytes: %v", err)
	}
	result, err := game.GetProtobufConverter()(protoBytes)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (c *APIClient) BetOrder(ctx context.Context, cfg *v1.TaskConfig, token string, game base.IGame) (map[string]any, error) {
	params := map[string]any{"gameId": cfg.GameId}
	if cfg.BetOrder != nil {
		params["baseMoney"] = cfg.BetOrder.BaseMoney
		params["multiple"] = cfg.BetOrder.Multiple
		params["purchase"] = cfg.BetOrder.Purchase
	}

	apiURL := c.baseApiURL + "/api/game/betorder"
	// BetOrder 错误处理逻辑复杂，不使用 postGeneric
	res, err := c.request(ctx, http.MethodPost, apiURL, params, token, false, nil)
	if err != nil {
		return nil, err
	}

	if res.Code != 0 {
		return nil, c.handleBetOrderError(res.Code, res.Msg)
	}

	if game != nil && game.GetProtobufConverter() != nil {
		return c.decodeProtobuf(cfg, res.Bytes, game)
	}

	var data map[string]any
	err = jsonAPI.Unmarshal(res.Data, &data)
	return data, err
}

func (c *APIClient) handleBetOrderError(code int, msg string) error {
	msg = strings.TrimSpace(msg)
	e := &BetOrderError{Code: code, Msg: msg}
	lmsg := strings.ToLower(msg)

	for _, kw := range relaunchKeywords {
		if strings.Contains(lmsg, kw) {
			e.NeedRelaunch = true
			if kw == "internal error" {
				e.SleepDuration = time.Second
			}
			return e
		}
	}

	if strings.Contains(lmsg, "limit") {
		e.NeedRelogin = true
		e.SleepDuration = 3 * time.Second
		return e
	}
	return e
}

type BetBonusResult struct {
	Data         map[string]any
	NeedContinue bool
}

func (c *APIClient) BetBonus(ctx context.Context, cfg *v1.TaskConfig, token string, bonusNum int64, game base.IGame) (*BetBonusResult, error) {
	params := map[string]any{"gameId": cfg.GameId, "bonusNum": bonusNum}
	apiURL := c.baseApiURL + "/api/game/betbonus"

	// 使用 generic，注意 map[string]any 也是一种 T
	data, err := postGeneric[map[string]any](c, ctx, apiURL, params, token)
	if err != nil {
		return nil, err
	}

	result := &BetBonusResult{Data: *data}
	if game != nil {
		if bi := game.AsBonusInterface(); bi != nil {
			result.NeedContinue = bi.BonusNextState(*data)
		}
	}
	return result, nil
}

func (c *APIClient) Close() {
	if c.http != nil {
		c.http.CloseIdleConnections()
	}
}
