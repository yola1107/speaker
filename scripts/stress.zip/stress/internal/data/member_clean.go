package data

import (
	"context"
	"fmt"

	"github.com/redis/go-redis/v9"
)

const (
	scanCount = 10000 // 每轮 SCAN 建议返回数量（Redis 可能多返回）
	pipeBatch = 1000  // 每批 Pipeline DEL 数量，平衡 RTT 与单次请求大小
)

// pipeliner 用于 SCAN + Pipeline DEL（同一节点上批量删，减少 RTT）
type pipeliner interface {
	Scan(ctx context.Context, cursor uint64, match string, count int64) *redis.ScanCmd
	Pipeline() redis.Pipeliner
}

// scanAndDelete 在单个 client 上 SCAN，用 Pipeline 分批 DEL，返回本节点删除数量
func (r *dataRepo) scanAndDelete(ctx context.Context, pattern string, client pipeliner) (int, error) {
	cursor := uint64(0)
	totalDeleted := 0
	for {
		select {
		case <-ctx.Done():
			return totalDeleted, ctx.Err()
		default:
		}
		keys, nextCursor, err := client.Scan(ctx, cursor, pattern, scanCount).Result()
		if err != nil {
			return totalDeleted, fmt.Errorf("scan failed: %w", err)
		}
		// 同一批 key 再按 pipeBatch 分包，避免单次 Pipeline 过大
		for i := 0; i < len(keys); i += pipeBatch {
			if ctx.Err() != nil {
				return totalDeleted, ctx.Err()
			}
			end := i + pipeBatch
			if end > len(keys) {
				end = len(keys)
			}
			batch := keys[i:end]
			pipe := client.Pipeline()
			for _, key := range batch {
				pipe.Del(ctx, key)
			}
			cmds, err := pipe.Exec(ctx)
			if err != nil {
				return totalDeleted, fmt.Errorf("pipeline del: %w", err)
			}
			for _, cmd := range cmds {
				if n, ok := cmd.(*redis.IntCmd); ok {
					v, _ := n.Result()
					totalDeleted += int(v)
				}
			}
		}
		cursor = nextCursor
		if cursor == 0 {
			break
		}
	}
	return totalDeleted, nil
}

// CleanRedisBySite 清理 Redis 中 site:* 的键（与 scripts/db-cleaner/clean.sh 一致，如 egame50001:*）
// 集群模式下 SCAN 只扫当前节点，需对每个 master 分别 SCAN 才能扫到全部 key
func (r *dataRepo) CleanRedisBySite(ctx context.Context, site, _ string) error {
	pattern := site + ":*" // 只按 site 清理，与 clean.sh 中 --pattern "$SITE:*" 一致
	r.log.Infof("Starting Redis cleanup for pattern: %s", pattern)

	rdb := r.data.rdb
	totalDeleted := 0

	if clu, ok := rdb.(*redis.ClusterClient); ok {
		// 集群：对每个 master 执行 SCAN + Pipeline DEL（同节点 key 一批发送，减少 RTT）
		err := clu.ForEachMaster(ctx, func(ctx context.Context, node *redis.Client) error {
			n, err := r.scanAndDelete(ctx, pattern, node)
			if err != nil {
				return err
			}
			totalDeleted += n
			return nil
		})
		if err != nil {
			return fmt.Errorf("cluster scan/delete for pattern %s: %w", pattern, err)
		}
	} else if p, ok := rdb.(pipeliner); ok {
		// 单机/哨兵：SCAN + Pipeline DEL（用接口断言，兼容 Client / FailoverClient）
		n, err := r.scanAndDelete(ctx, pattern, p)
		if err != nil {
			return fmt.Errorf("scan/delete for pattern %s: %w", pattern, err)
		}
		totalDeleted = n
	} else {
		return fmt.Errorf("redis client type %T does not support scan+pipeline", rdb)
	}

	if totalDeleted > 0 {
		r.log.Infof("Successfully cleaned %d keys for pattern: %s", totalDeleted, pattern)
	} else {
		r.log.Infof("No keys found for pattern: %s", pattern)
	}
	return nil
}

// CleanGameOrderTable 清空 game_order 表（使用订单库）
func (r *dataRepo) CleanGameOrderTable(ctx context.Context) error {
	orderDB := r.data.order
	if orderDB == nil {
		return fmt.Errorf("order database not configured")
	}
	// 先获取清理前的记录数用于日志
	count, err := r.GetGameOrderCount(ctx)
	if err != nil {
		r.log.Warnf("Failed to get count before truncate: %v", err)
	} else {
		r.log.Infof("Truncating game_order table with %d records", count)
	}

	// 执行 TRUNCATE TABLE（连接已指向 egame_order 库，表名用 game_order）
	_, err = orderDB.Exec("TRUNCATE TABLE game_order")
	if err != nil {
		return fmt.Errorf("failed to truncate game_order table: %w", err)
	}

	// 验证清理结果
	finalCount, _ := r.GetGameOrderCount(ctx)
	if finalCount > 0 {
		r.log.Warnf("Table still has %d records after truncate, may need manual check", finalCount)
	} else {
		r.log.Info("Game order table truncated successfully, table is now empty")
	}

	return nil
}

// GetGameOrderCount 获取 game_order 表记录数（使用订单库）
func (r *dataRepo) GetGameOrderCount(ctx context.Context) (int64, error) {
	orderDB := r.data.order
	if orderDB == nil {
		return 0, fmt.Errorf("order database not configured")
	}
	var count int64
	has, err := orderDB.Context(ctx).SQL("SELECT COUNT(*) FROM game_order").Get(&count)
	if err != nil {
		return 0, fmt.Errorf("failed to get game_order count: %w", err)
	}
	if !has {
		return 0, nil
	}
	return count, nil
}
